import SwiftUI
import UIKit
import WebKit

struct Toast: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let icon: String
    let isError: Bool
}

/// 避免 WKUserContentController 强引用造成循环引用
final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        target?.userContentController(c, didReceive: m)
    }
}

/// 内置 WhatsApp（网页版，官方“关联设备”功能）+ 免费翻译
///  - 每条消息气泡里直接显示译文（对方 = 黄色，我 = 蓝色）
///  - 底部：打中文 → 译文确认框实时更新（可修改）→ 点“确认译文”才填入 WhatsApp 并发送
final class AppModel: NSObject, ObservableObject {
    static let waURL = URL(string: "https://web.whatsapp.com/")!

    let web: WKWebView
    private let tr = Translator()
    private var injectJs = ""
    private var timer: Timer?

    // 页面状态
    @Published var chatOpen = false
    @Published var bubblesOff = false
    @Published var mobileLayout = true
    @Published var detectedTheirLang: String?
    @Published var overrideTarget: String?

    // 底部输入
    @Published var zh = "" {
        didSet { if zh != oldValue { zhChanged() } }
    }
    @Published var translation = "" {
        didSet { if !settingTr && translation != oldValue { trEdited = true } }
    }
    @Published var translating = false
    @Published var sending = false
    @Published var trEdited = false
    @Published var errorText: String?

    // 界面
    @Published var toast: Toast?
    @Published var showSettings = false
    @Published var diagnostics: String?
    @Published var showDiagnostics = false

    private var settingTr = false
    private var liveSeq = 0
    private var liveSource = ""
    private var liveTarget = ""
    private var debounce: DispatchWorkItem?
    private var toastHide: DispatchWorkItem?

    private var currentChat = ""
    private var announcedOn = false
    private var zeroFoundTicks = 0
    private var warnedNoMsg = false
    private var warnedFail = false

    override init() {
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .default()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        let ucc = WKUserContentController()
        cfg.userContentController = ucc
        web = WKWebView(frame: .zero, configuration: cfg)
        if let url = Bundle.main.url(forResource: "inject", withExtension: "js"),
           let s = try? String(contentsOf: url, encoding: .utf8) {
            injectJs = s
        }
        super.init()

        ucc.add(WeakScriptHandler(self), name: "WaTr")
        ucc.addUserScript(WKUserScript(source: injectJs, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        web.customUserAgent = Translator.userAgent
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = false
        web.isOpaque = false
        web.backgroundColor = .systemBackground
        if #available(iOS 16.4, *) { web.isInspectable = true }

        // 从屏幕左边缘右滑 = 返回聊天列表（和 iOS 习惯一致）
        let edge = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(edgeSwipe(_:)))
        edge.edges = .left
        web.addGestureRecognizer(edge)

        web.load(URLRequest(url: AppModel.waURL))
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            self?.inject()
            self?.checkStatus()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in self?.selfTest() }
    }

    deinit { timer?.invalidate() }

    // MARK: - 计算属性

    var outgoingTarget: String {
        if let o = overrideTarget { return o }
        if Prefs.autoDetect, let d = detectedTheirLang { return d }
        return Prefs.theirLang
    }
    var isAutoTarget: Bool { overrideTarget == nil }
    var showCard: Bool { !zh.trimmed.isEmpty || !translation.trimmed.isEmpty }
    var canConfirm: Bool { !sending && showCard }

    // MARK: - 提示条

    func showToast(_ text: String, icon: String = "info.circle.fill", error: Bool = false, seconds: Double = 2.5) {
        toastHide?.cancel()
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
            toast = Toast(text: text, icon: icon, isError: error)
        }
        let w = DispatchWorkItem { [weak self] in
            withAnimation(.easeOut(duration: 0.25)) { self?.toast = nil }
        }
        toastHide = w
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: w)
    }

    private func selfTest() {
        tr.translateAuto("Good morning", to: Prefs.myLang) { [weak self] r in
            if let r = r {
                self?.showToast("翻译服务正常（\(r.engine)）", icon: "checkmark.circle.fill")
            } else {
                self?.showToast("连不上谷歌 / 微软翻译，请检查网络（可能需要 VPN）",
                                icon: "wifi.exclamationmark", error: true, seconds: 5)
            }
        }
    }

    // MARK: - 注入脚本 / 状态

    func inject() {
        web.evaluateJavaScript(injectJs + "\n;0", completionHandler: nil)
        web.evaluateJavaScript("window.__wa && __wa.mobile !== \(mobileLayout) && __wa.setMobile(\(mobileLayout)); 0",
                               completionHandler: nil)
    }

    /// 读取页面状态（只看数量和聊天是否切换，不读聊天内容）
    private func checkStatus() {
        web.evaluateJavaScript("window.__wa ? __wa.stats() : ''") { [weak self] res, _ in
            guard let self = self, let s = res as? String, let data = s.data(using: .utf8),
                  let o = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return }
            let hasMain = (o["main"] as? NSNumber)?.boolValue ?? false
            let hasInput = (o["input"] as? NSNumber)?.boolValue ?? false
            let found = (o["found"] as? NSNumber)?.intValue ?? 0
            let done = (o["done"] as? NSNumber)?.intValue ?? 0
            let failed = (o["failed"] as? NSNumber)?.intValue ?? 0
            let chat = o["chat"] as? String ?? ""

            // 切换了聊天：重置语言和输入
            if chat != self.currentChat {
                self.currentChat = chat
                self.detectedTheirLang = nil
                self.overrideTarget = nil
                self.resetComposer()
            }
            let open = hasMain && hasInput
            if open != self.chatOpen {
                withAnimation(.easeInOut(duration: 0.25)) { self.chatOpen = open }
            }

            if hasMain && found > 0 && !self.announcedOn {
                self.announcedOn = true
                self.showToast("双语翻译已开启", icon: "character.bubble.fill")
            }
            if hasMain && found == 0 {
                self.zeroFoundTicks += 1
                if self.zeroFoundTicks >= 3 && !self.warnedNoMsg {
                    self.warnedNoMsg = true
                    self.showToast("没识别到消息：可在 ⋯ → 诊断 里查看", icon: "exclamationmark.triangle.fill",
                                   error: true, seconds: 5)
                }
            } else {
                self.zeroFoundTicks = 0
            }
            if failed > 0 && done == 0 && !self.warnedFail {
                self.warnedFail = true
                self.showToast("翻译失败：连不上谷歌 / 微软翻译，请检查网络", icon: "wifi.exclamationmark",
                               error: true, seconds: 5)
            }
        }
    }

    // MARK: - 气泡翻译

    private func translateMessage(id: String, text: String, outgoing: Bool) {
        let my = Prefs.myLang
        tr.translateAuto(text, to: my) { [weak self] r in
            guard let self = self else { return }
            guard let r = r else { self.setBubble(id, "⚠ 翻译失败（连不上谷歌/微软翻译）", failed: true); return }
            let alreadyMine = r.src == my || r.text.trimmed.caseInsensitiveCompare(text.trimmed) == .orderedSame
            if !alreadyMine {
                // 外语消息 → 显示中文译文；对方用什么语言，我回复就译成什么语言
                if !outgoing && !r.src.isEmpty && r.src != self.detectedTheirLang {
                    self.detectedTheirLang = r.src
                }
                self.setBubble(id, r.text, failed: false)
            } else if outgoing {
                let tgt = self.outgoingTarget
                if tgt == my { self.setBubble(id, "", failed: false); return }
                self.tr.translate(text, from: my, to: tgt) { t in
                    if let t = t { self.setBubble(id, t, failed: false) }
                    else { self.setBubble(id, "⚠ 翻译失败", failed: true) }
                }
            } else {
                self.setBubble(id, "", failed: false)
            }
        }
    }

    private func setBubble(_ id: String, _ text: String, failed: Bool) {
        web.evaluateJavaScript("window.__trSet && __trSet(\(jsLiteral(id)), \(jsLiteral(text)), \(failed)); 0",
                               completionHandler: nil)
    }

    // MARK: - 底部：中文 → 译文确认框

    private func setTranslation(_ t: String) {
        settingTr = true
        translation = t
        settingTr = false
        trEdited = false
    }

    private func resetComposer() {
        liveSeq += 1
        liveSource = ""
        debounce?.cancel()
        translating = false
        errorText = nil
        if !zh.isEmpty { zh = "" }
        setTranslation("")
    }

    /// 中文变了：稍等一下再翻译。不会碰 WhatsApp 输入框。
    private func zhChanged() {
        debounce?.cancel()
        let text = zh.trimmed
        if text.isEmpty {
            liveSeq += 1
            liveSource = ""
            translating = false
            errorText = nil
            setTranslation("")
            return
        }
        trEdited = false          // 中文改了，以新译文为准
        translating = true
        errorText = nil
        let w = DispatchWorkItem { [weak self] in self?.translateLive(sendAfter: false) }
        debounce = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: w)
    }

    /// 实时翻译，结果只放进译文确认框；sendAfter = true 时翻译完接着填入并发送
    private func translateLive(sendAfter: Bool) {
        let text = zh.trimmed
        if text.isEmpty { sending = false; translating = false; return }
        let my = Prefs.myLang
        let tgt = outgoingTarget
        if text == liveSource && tgt == liveTarget && !translation.trimmed.isEmpty {
            translating = false
            if sendAfter { fillAndSend(translation.trimmed) }
            return
        }
        liveSeq += 1
        let seq = liveSeq
        if my == tgt { showLive(text, text, tgt, seq, sendAfter); return }
        translating = true
        tr.translate(text, from: my, to: tgt) { [weak self] r in
            guard let self = self, seq == self.liveSeq else { return }   // 已经有更新的输入了
            self.translating = false
            guard let r = r else {
                self.errorText = "翻译失败，请检查网络；也可以直接在上面手写译文"
                self.sending = false
                return
            }
            self.showLive(text, r, tgt, seq, sendAfter)
        }
    }

    private func showLive(_ src: String, _ result: String, _ tgt: String, _ seq: Int, _ sendAfter: Bool) {
        liveSource = src
        liveTarget = tgt
        translating = false
        errorText = nil
        setTranslation(result)
        if sendAfter && seq == liveSeq { fillAndSend(result) }
    }

    func setTarget(_ code: String?) {
        overrideTarget = code
        if let code = code { Prefs.theirLang = code }
        if !zh.trimmed.isEmpty {
            liveSource = ""
            translating = true
            translateLive(sendAfter: false)
        }
    }

    /// 点“确认译文”
    func confirm() {
        guard !sending else { return }
        let z = zh.trimmed
        let t = translation.trimmed
        if z.isEmpty && t.isEmpty { return }
        sending = true
        debounce?.cancel()
        // 用户改过译文，或译文已对应当前中文：直接用框里的译文
        let upToDate = z.isEmpty || trEdited || (z == liveSource && outgoingTarget == liveTarget && !t.isEmpty)
        if upToDate && !t.isEmpty { fillAndSend(t) } else { translateLive(sendAfter: true) }
    }

    private func norm(_ s: String) -> String {
        s.replacingOccurrences(of: "\u{00A0}", with: " ")
            .components(separatedBy: .whitespacesAndNewlines)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }

    /// 把译文一次性填进 WhatsApp 输入框 → 等页面更新后核对 → 一致才点发送。
    /// 核对之前绝不补写，避免出现“译文重复两遍”。
    private func fillAndSend(_ text: String) {
        if text.isEmpty { sending = false; return }
        web.evaluateJavaScript("window.__wa ? __wa.setInput(\(jsLiteral(text))) : 'noinput'") { [weak self] r, _ in
            guard let self = self else { return }
            if (r as? String) == "noinput" { self.fillFailed(text, "没找到 WhatsApp 输入框"); return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self.verifyThenSend(text, triedPaste: false) }
        }
    }

    private func verifyThenSend(_ text: String, triedPaste: Bool) {
        web.evaluateJavaScript("window.__wa ? __wa.getInput() : '__NOINPUT__'") { [weak self] raw, _ in
            guard let self = self else { return }
            let now = self.norm(raw as? String ?? "")
            if now == self.norm(text) {
                self.clickSend()
            } else if now.isEmpty && !triedPaste {
                // 第一种方法没写进去（输入框还是空的），才换粘贴方式写一次
                self.web.evaluateJavaScript("window.__wa ? __wa.pasteInput(\(jsLiteral(text))) : 'noinput'") { _, _ in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                        self.verifyThenSend(text, triedPaste: true)
                    }
                }
            } else {
                // 内容对不上：清空 WhatsApp 输入框，不发送
                self.web.evaluateJavaScript("window.__wa && __wa.setInput(''); 0", completionHandler: nil)
                self.fillFailed(text, "没能正确填入 WhatsApp 输入框")
            }
        }
    }

    private func fillFailed(_ text: String, _ why: String) {
        sending = false
        UIPasteboard.general.string = text
        errorText = "\(why)。译文已复制，可长按 WhatsApp 输入框粘贴后发送"
        UINotificationFeedbackGenerator().notificationOccurred(.error)
    }

    private func clickSend() {
        web.evaluateJavaScript("window.__wa ? __wa.send() : 'noinput'") { [weak self] how, _ in
            guard let self = self else { return }
            self.sending = false
            if (how as? String) == "noinput" {
                self.errorText = "没找到 WhatsApp 的发送按钮，译文已在输入框里，请手动发送"
                return
            }
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            self.resetComposer()
            self.showToast("已发送", icon: "checkmark.circle.fill", seconds: 1.5)
        }
    }

    // MARK: - 菜单操作

    func backToList() {
        web.evaluateJavaScript("window.__wa && __wa.list(); 0", completionHandler: nil)
    }

    @objc private func edgeSwipe(_ g: UIScreenEdgePanGestureRecognizer) {
        if g.state == .ended && chatOpen { backToList() }
    }

    func setBubbles(on: Bool) {
        bubblesOff = !on
        web.evaluateJavaScript("window.__wa && __wa.setOff(\(!on)); 0", completionHandler: nil)
    }

    func toggleLayout() {
        mobileLayout.toggle()
        inject()
    }

    func reload() {
        web.reload()
    }

    func settingsChanged() {
        objectWillChange.send()
        if !zh.trimmed.isEmpty {
            liveSource = ""
            translating = true
            translateLive(sendAfter: false)
        }
    }

    func runDiagnostics() {
        web.evaluateJavaScript("window.__wa ? __wa.stats() : 'NOT_INJECTED'") { [weak self] raw, _ in
            guard let self = self else { return }
            let info = raw as? String ?? "NOT_INJECTED"
            self.tr.translateAuto("Good morning", to: Prefs.myLang) { r in
                let net = r == nil ? "翻译服务：连不上" : "翻译服务：正常（\(r!.engine)）"
                self.diagnostics = "iOS v1.0 engine=\(Prefs.engine) my=\(Prefs.myLang) " +
                    "target=\(self.outgoingTarget)\n\(net)\n\(info)"
                self.showDiagnostics = true
            }
        }
    }
}

// MARK: - WebKit 回调

extension AppModel: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "WaTr", let d = message.body as? [String: Any],
              let id = d["id"] as? String, let text = d["text"] as? String else { return }
        let out = (d["out"] as? NSNumber)?.boolValue ?? false
        translateMessage(id: id, text: text, outgoing: out)
    }
}

extension AppModel: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        inject()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let url = navigationAction.request.url
        let isMain = navigationAction.targetFrame?.isMainFrame ?? true
        guard let u = url, let host = u.host, isMain,
              u.scheme == "http" || u.scheme == "https" else {
            decisionHandler(.allow); return
        }
        if host.hasSuffix("whatsapp.com") || host.hasSuffix("whatsapp.net") {
            decisionHandler(.allow); return
        }
        // 聊天里的外部链接用 Safari 打开
        UIApplication.shared.open(u)
        decisionHandler(.cancel)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }
}

extension AppModel: WKUIDelegate {
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = navigationAction.request.url, u.scheme == "http" || u.scheme == "https" {
            UIApplication.shared.open(u)
        }
        return nil
    }

    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.grant)
    }
}
