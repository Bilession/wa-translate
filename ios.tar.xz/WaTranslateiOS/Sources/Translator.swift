import Foundation

/// 翻译结果：译文、识别出的源语言、实际使用的引擎
struct TrResult {
    let text: String
    let src: String
    let engine: String
}

/// 翻译引擎（全部免费、无需 API Key、不消耗 token）：
///  - 谷歌翻译（默认）
///  - 微软翻译（谷歌不通时自动备用）
/// 所有回调都在主线程。
final class Translator {
    static let userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 " +
        "(KHTML, like Gecko) Version/17.5 Safari/605.1.15"

    private var cache: [String: TrResult] = [:]   // 只在主线程访问
    private let session: URLSession
    private let tokenLock = NSLock()
    private var msToken: String?
    private var msTokenAt = Date.distantPast

    init() {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 10
        c.timeoutIntervalForResource = 15
        session = URLSession(configuration: c)
    }

    /// 自动识别源语言，翻译成 tgt。失败回调 nil。
    func translateAuto(_ text: String, to tgt: String, _ cb: @escaping (TrResult?) -> Void) {
        run(text, nil, tgt, cb)
    }

    /// 指定源语言翻译。失败回调 nil。
    func translate(_ text: String, from src: String, to tgt: String, _ cb: @escaping (String?) -> Void) {
        if src == tgt { cb(text); return }
        run(text, src, tgt) { cb($0?.text) }
    }

    private func run(_ text: String, _ src: String?, _ tgt: String, _ cb: @escaping (TrResult?) -> Void) {
        let engine = Prefs.engine
        let key = "\(engine)|\(src ?? "auto")|\(tgt)|\(text)"
        if let c = cache[key] { cb(c); return }
        let order = engine == "microsoft" ? ["microsoft", "google"] : ["google", "microsoft"]
        attempt(order, 0, text, src, tgt) { [weak self] r in
            DispatchQueue.main.async {
                if let r = r, let self = self {
                    if self.cache.count > 1500 { self.cache.removeAll() }
                    self.cache[key] = r
                }
                cb(r)
            }
        }
    }

    private func attempt(_ order: [String], _ i: Int, _ text: String, _ src: String?, _ tgt: String,
                         _ done: @escaping (TrResult?) -> Void) {
        if i >= order.count { done(nil); return }
        let next: (TrResult?) -> Void = { [weak self] r in
            if let r = r, !r.text.trimmed.isEmpty { done(r); return }
            guard let self = self else { done(nil); return }
            self.attempt(order, i + 1, text, src, tgt, done)
        }
        if order[i] == "google" { google(text, src, tgt, next) } else { microsoft(text, src, tgt, next) }
    }

    // MARK: 语言代码

    /// 把各家接口返回的语言代码统一成 App 内部代码（zh / en / es …）
    static func norm(_ code: String?) -> String {
        let c = (code ?? "").trimmed.lowercased()
        if c.isEmpty { return "" }
        if c.hasPrefix("zh") { return "zh" }
        if c == "iw" { return "he" }
        if c == "fil" { return "tl" }
        return String(c.split(separator: "-").first ?? Substring(c))
    }

    private func gCode(_ l: String) -> String {
        switch l { case "zh": return "zh-CN"; case "he": return "iw"; default: return l }
    }
    private func msCode(_ l: String) -> String {
        switch l { case "zh": return "zh-Hans"; case "tl": return "fil"; default: return l }
    }

    private static let formAllowed: CharacterSet = {
        var s = CharacterSet.alphanumerics
        s.insert(charactersIn: "-._~")
        return s
    }()
    private func enc(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: Translator.formAllowed) ?? ""
    }

    // MARK: 谷歌翻译（免费网页接口）

    private func google(_ text: String, _ src: String?, _ tgt: String, _ done: @escaping (TrResult?) -> Void) {
        let base = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t" +
            "&sl=\(src.map { gCode($0) } ?? "auto")&tl=\(gCode(tgt))"
        let q = enc(text)
        var req: URLRequest
        if q.count < 1800, let url = URL(string: base + "&q=" + q) {
            req = URLRequest(url: url)
        } else {
            guard let url = URL(string: base) else { done(nil); return }
            req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.setValue("application/x-www-form-urlencoded;charset=UTF-8", forHTTPHeaderField: "Content-Type")
            req.httpBody = ("q=" + q).data(using: .utf8)
        }
        req.setValue(Translator.userAgent, forHTTPHeaderField: "User-Agent")
        session.dataTask(with: req) { data, resp, _ in
            guard let data = data, (resp as? HTTPURLResponse)?.statusCode ?? 0 < 300,
                  let arr = (try? JSONSerialization.jsonObject(with: data)) as? [Any],
                  let segs = arr.first as? [Any] else { done(nil); return }
            var out = ""
            for seg in segs {
                if let s = seg as? [Any], let t = s.first as? String { out += t }
            }
            let detected = src ?? Translator.norm(arr.count > 2 ? arr[2] as? String : nil)
            done(TrResult(text: out.trimmed, src: detected, engine: "谷歌"))
        }.resume()
    }

    // MARK: 微软翻译（Edge 浏览器内置的免费接口）

    private func microsoft(_ text: String, _ src: String?, _ tgt: String, _ done: @escaping (TrResult?) -> Void) {
        msTokenValue { [weak self] token in
            guard let self = self, let token = token else { done(nil); return }
            var s = "https://api-edge.cognitive.microsofttranslator.com/translate?api-version=3.0&to=\(self.msCode(tgt))"
            if let src = src { s += "&from=\(self.msCode(src))" }
            guard let url = URL(string: s),
                  let body = try? JSONSerialization.data(withJSONObject: [["Text": text]]) else { done(nil); return }
            var req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.httpBody = body
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            req.setValue(Translator.userAgent, forHTTPHeaderField: "User-Agent")
            self.session.dataTask(with: req) { data, resp, _ in
                guard let data = data, (resp as? HTTPURLResponse)?.statusCode ?? 0 < 300,
                      let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]],
                      let o = arr.first,
                      let trs = o["translations"] as? [[String: Any]],
                      let t = trs.first?["text"] as? String else { done(nil); return }
                let det = (o["detectedLanguage"] as? [String: Any])?["language"] as? String
                done(TrResult(text: t.trimmed, src: src ?? Translator.norm(det), engine: "微软"))
            }.resume()
        }
    }

    private func msTokenValue(_ cb: @escaping (String?) -> Void) {
        tokenLock.lock()
        let cached = msToken
        let fresh = Date().timeIntervalSince(msTokenAt) < 8 * 60
        tokenLock.unlock()
        if let t = cached, fresh { cb(t); return }
        guard let url = URL(string: "https://edge.microsoft.com/translate/auth") else { cb(nil); return }
        var req = URLRequest(url: url)
        req.setValue(Translator.userAgent, forHTTPHeaderField: "User-Agent")
        session.dataTask(with: req) { [weak self] data, resp, _ in
            guard let self = self, let data = data, (resp as? HTTPURLResponse)?.statusCode ?? 0 < 300,
                  let t = String(data: data, encoding: .utf8)?.trimmed, !t.isEmpty else { cb(nil); return }
            self.tokenLock.lock()
            self.msToken = t
            self.msTokenAt = Date()
            self.tokenLock.unlock()
            cb(t)
        }.resume()
    }
}
