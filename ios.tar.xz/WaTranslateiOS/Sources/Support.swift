import Foundation

/// 用户设置（与设置页的 @AppStorage 使用相同的键）
enum Prefs {
    private static var d: UserDefaults { .standard }

    static var myLang: String { d.string(forKey: "myLang") ?? "zh" }
    static var theirLang: String {
        get { d.string(forKey: "theirLang") ?? "en" }
        set { d.set(newValue, forKey: "theirLang") }
    }
    static var autoDetect: Bool { d.object(forKey: "autoDetect") as? Bool ?? true }
    /// 翻译引擎：google / microsoft
    static var engine: String { d.string(forKey: "engine") ?? "google" }
}

struct Lang: Identifiable, Hashable {
    let code: String
    let name: String      // 中文名
    let native: String    // 本地名
    var id: String { code }
}

enum Langs {
    // 谷歌 / 微软翻译都支持的语言
    static let all: [Lang] = [
        Lang(code: "zh", name: "中文", native: "中文"),
        Lang(code: "en", name: "英语", native: "English"),
        Lang(code: "es", name: "西班牙语", native: "Español"),
        Lang(code: "pt", name: "葡萄牙语", native: "Português"),
        Lang(code: "ar", name: "阿拉伯语", native: "العربية"),
        Lang(code: "ru", name: "俄语", native: "Русский"),
        Lang(code: "fr", name: "法语", native: "Français"),
        Lang(code: "de", name: "德语", native: "Deutsch"),
        Lang(code: "it", name: "意大利语", native: "Italiano"),
        Lang(code: "ja", name: "日语", native: "日本語"),
        Lang(code: "ko", name: "韩语", native: "한국어"),
        Lang(code: "vi", name: "越南语", native: "Tiếng Việt"),
        Lang(code: "th", name: "泰语", native: "ไทย"),
        Lang(code: "id", name: "印尼语", native: "Indonesia"),
        Lang(code: "ms", name: "马来语", native: "Melayu"),
        Lang(code: "tl", name: "菲律宾语", native: "Tagalog"),
        Lang(code: "hi", name: "印地语", native: "हिन्दी"),
        Lang(code: "ur", name: "乌尔都语", native: "اردو"),
        Lang(code: "bn", name: "孟加拉语", native: "বাংলা"),
        Lang(code: "fa", name: "波斯语", native: "فارسی"),
        Lang(code: "tr", name: "土耳其语", native: "Türkçe"),
        Lang(code: "nl", name: "荷兰语", native: "Nederlands"),
        Lang(code: "pl", name: "波兰语", native: "Polski"),
        Lang(code: "uk", name: "乌克兰语", native: "Українська"),
        Lang(code: "he", name: "希伯来语", native: "עברית"),
        Lang(code: "sw", name: "斯瓦希里语", native: "Kiswahili")
    ]

    static func name(_ code: String) -> String {
        all.first(where: { $0.code == code })?.name ?? code
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}

/// 把 Swift 字符串安全地变成 JS 字符串字面量
func jsLiteral(_ s: String) -> String {
    if let d = try? JSONSerialization.data(withJSONObject: [s]),
       let str = String(data: d, encoding: .utf8), str.count >= 2 {
        return String(str.dropFirst().dropLast())
    }
    return "''"
}
