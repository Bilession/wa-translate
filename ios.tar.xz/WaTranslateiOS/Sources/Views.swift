import SwiftUI
import UIKit
import WebKit

@main
struct WaTranslateApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct WebViewContainer: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - 主界面

struct ContentView: View {
    @StateObject private var m = AppModel()

    var body: some View {
        VStack(spacing: 0) {
            TopBar(m: m)
            WebViewContainer(web: m.web)
            if m.chatOpen {
                Composer(m: m)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .background(Color(.systemBackground))
        .overlay(alignment: .top) {
            if let t = m.toast {
                ToastView(toast: t)
                    .padding(.top, 52)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .onTapGesture { withAnimation { m.toast = nil } }
            }
        }
        .sheet(isPresented: $m.showSettings, onDismiss: { m.settingsChanged() }) {
            SettingsView(m: m)
        }
        .alert("诊断信息", isPresented: $m.showDiagnostics) {
            Button("复制") { UIPasteboard.general.string = m.diagnostics ?? "" }
            Button("关闭", role: .cancel) {}
        } message: {
            Text((m.diagnostics ?? "") + "\n\n只含页面结构统计，不含聊天内容。")
        }
    }
}

// MARK: - 顶部导航栏

struct TopBar: View {
    @ObservedObject var m: AppModel

    var body: some View {
        ZStack {
            if m.chatOpen {
                Menu {
                    LanguageMenu(m: m)
                } label: {
                    HStack(spacing: 4) {
                        Text("译成\(Langs.name(m.outgoingTarget))")
                            .font(.headline)
                            .foregroundColor(.primary)
                        Image(systemName: "chevron.down.circle.fill")
                            .symbolRenderingMode(.hierarchical)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
            } else {
                Text("WA 翻译").font(.headline)
            }

            HStack {
                if m.chatOpen {
                    Button {
                        m.backToList()
                    } label: {
                        HStack(spacing: 3) {
                            Image(systemName: "chevron.left").font(.body.weight(.semibold))
                            Text("聊天")
                        }
                    }
                }
                Spacer()
                Menu {
                    MoreMenu(m: m)
                } label: {
                    Image(systemName: "ellipsis.circle")
                        .font(.title3)
                        .frame(width: 44, height: 44, alignment: .trailing)
                }
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 44)
        .background(.bar, ignoresSafeAreaEdges: .top)
        .overlay(alignment: .bottom) { Divider() }
    }
}

struct LanguageMenu: View {
    @ObservedObject var m: AppModel

    var body: some View {
        Section("把我的话翻译成") {
            Button {
                m.setTarget(nil)
            } label: {
                if m.isAutoTarget {
                    Label("自动（跟随对方语言）", systemImage: "checkmark")
                } else {
                    Text("自动（跟随对方语言）")
                }
            }
        }
        Section {
            ForEach(Langs.all.filter { $0.code != Prefs.myLang }) { l in
                Button {
                    m.setTarget(l.code)
                } label: {
                    if !m.isAutoTarget && m.outgoingTarget == l.code {
                        Label("\(l.name)  \(l.native)", systemImage: "checkmark")
                    } else {
                        Text("\(l.name)  \(l.native)")
                    }
                }
            }
        }
    }
}

struct MoreMenu: View {
    @ObservedObject var m: AppModel

    var body: some View {
        Section {
            if m.chatOpen {
                Button { m.backToList() } label: { Label("返回聊天列表", systemImage: "list.bullet") }
            }
            Button {
                m.setBubbles(on: m.bubblesOff)
            } label: {
                Label(m.bubblesOff ? "显示气泡译文" : "隐藏气泡译文",
                      systemImage: m.bubblesOff ? "eye" : "eye.slash")
            }
        }
        Section {
            Button { m.reload() } label: { Label("刷新页面", systemImage: "arrow.clockwise") }
            Button { m.toggleLayout() } label: {
                Label(m.mobileLayout ? "切换到电脑版布局" : "切换到手机版布局",
                      systemImage: m.mobileLayout ? "desktopcomputer" : "iphone")
            }
        }
        Section {
            Button { m.showSettings = true } label: { Label("设置", systemImage: "gearshape") }
            Button { m.runDiagnostics() } label: { Label("诊断", systemImage: "stethoscope") }
        }
    }
}

// MARK: - 底部：译文确认框 + 中文输入

struct Composer: View {
    @ObservedObject var m: AppModel
    @FocusState private var zhFocused: Bool

    var body: some View {
        VStack(spacing: 8) {
            if m.showCard {
                card.transition(.move(edge: .bottom).combined(with: .opacity))
            }
            HStack(alignment: .bottom, spacing: 8) {
                TextField("输入中文", text: $m.zh, axis: .vertical)
                    .lineLimit(1...5)
                    .focused($zhFocused)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(Color(.systemBackground),
                                in: RoundedRectangle(cornerRadius: 19, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous)
                        .strokeBorder(Color(.separator), lineWidth: 0.5))

                Button {
                    m.confirm()
                } label: {
                    ZStack {
                        Text("确认译文").opacity(m.sending ? 0 : 1)
                        if m.sending { ProgressView().tint(.white) }
                    }
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 15)
                    .frame(height: 38)
                    .background(Capsule().fill(m.canConfirm ? Color.accentColor : Color(.systemGray3)))
                }
                .disabled(!m.canConfirm)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(.bar, ignoresSafeAreaEdges: .bottom)
        .overlay(alignment: .top) { Divider() }
        .animation(.easeInOut(duration: 0.2), value: m.showCard)
    }

    private var card: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: "character.bubble.fill")
                    .foregroundColor(.accentColor)
                Text("译文 · \(Langs.name(m.outgoingTarget))")
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(.secondary)
                Spacer()
                if m.translating {
                    ProgressView().controlSize(.small)
                } else if m.trEdited {
                    Text("已手动修改").font(.caption).foregroundColor(.orange)
                }
            }
            if let e = m.errorText {
                Text(e)
                    .font(.footnote)
                    .foregroundColor(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }
            TextField("译文会显示在这里，可直接修改", text: $m.translation, axis: .vertical)
                .lineLimit(1...4)
                .font(.body)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.accentColor.opacity(0.08),
                    in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
            .strokeBorder(Color.accentColor.opacity(0.25), lineWidth: 0.5))
    }
}

// MARK: - 顶部提示条

struct ToastView: View {
    let toast: Toast

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: toast.icon)
                .foregroundColor(toast.isError ? .red : .accentColor)
            Text(toast.text)
                .font(.subheadline)
                .foregroundColor(.primary)
                .lineLimit(3)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: .black.opacity(0.12), radius: 12, y: 4)
        .padding(.horizontal, 24)
    }
}

// MARK: - 设置

struct SettingsView: View {
    @ObservedObject var m: AppModel
    @Environment(\.dismiss) private var dismiss
    @AppStorage("myLang") private var myLang = "zh"
    @AppStorage("theirLang") private var theirLang = "en"
    @AppStorage("autoDetect") private var autoDetect = true
    @AppStorage("engine") private var engine = "google"

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("我的语言", selection: $myLang) {
                        ForEach(Langs.all) { Text($0.name).tag($0.code) }
                    }
                    Picker("对方语言", selection: $theirLang) {
                        ForEach(Langs.all) { Text($0.name).tag($0.code) }
                    }
                    Toggle("自动识别对方语言", isOn: $autoDetect)
                } header: {
                    Text("语言")
                } footer: {
                    Text("开启后，回复时会自动翻译成对方正在使用的语言；也可以在聊天顶部临时切换。")
                }

                Section {
                    Picker("翻译引擎", selection: $engine) {
                        Text("谷歌翻译").tag("google")
                        Text("微软翻译").tag("microsoft")
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text("翻译引擎")
                } footer: {
                    Text("都是免费接口，不消耗 token。首选的连不上时会自动换用另一个。")
                }

                Section {
                    Toggle("在气泡中显示译文", isOn: Binding(
                        get: { !m.bubblesOff },
                        set: { m.setBubbles(on: $0) }))
                } header: {
                    Text("显示")
                } footer: {
                    Text("对方的消息下方显示黄色译文，我的消息下方显示蓝色译文。")
                }

                Section("如何发送") {
                    StepRow(n: 1, text: "在底部输入框打中文")
                    StepRow(n: 2, text: "上方蓝框实时出现译文，可直接修改")
                    StepRow(n: 3, text: "点「确认译文」，译文才会填进 WhatsApp 并发送")
                }

                Section("首次登录") {
                    StepRow(n: 1, text: "等出现二维码页面，点「Log in with phone number / 用电话号码登录」，输入 WhatsApp 号码，记下 8 位代码")
                    StepRow(n: 2, text: "打开原版 WhatsApp → 设置 → 已关联的设备 → 关联新设备 → 改用电话号码关联 → 输入代码")
                    StepRow(n: 3, text: "回到本 App 即登录完成，以后不用再登")
                }

                Section {
                    LabeledContent("版本", value: "1.0")
                } footer: {
                    Text("消息通知、语音/视频通话仍由原版 WhatsApp 负责。从屏幕左边缘右滑可返回聊天列表。")
                }
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }
}

struct StepRow: View {
    let n: Int
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text("\(n)")
                .font(.footnote.weight(.bold))
                .foregroundColor(.white)
                .frame(width: 22, height: 22)
                .background(Circle().fill(Color.accentColor))
            Text(text)
                .font(.subheadline)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 2)
    }
}
