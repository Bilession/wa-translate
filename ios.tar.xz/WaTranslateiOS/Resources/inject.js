// 注入到 WhatsApp 网页版的脚本：把译文直接写进每条消息气泡（双语对照）
// 样式全部用 element.style 设置（不受网页安全策略 CSP 拦截）
(function () {
  // iOS：把 WKWebView 的消息通道包装成和安卓一样的 WaTr.translate()
  if (typeof window.WaTr === 'undefined' && window.webkit && window.webkit.messageHandlers &&
      window.webkit.messageHandlers.WaTr) {
    window.WaTr = {
      translate: function (id, t, out) {
        window.webkit.messageHandlers.WaTr.postMessage({ id: id, text: t, out: !!out });
      }
    };
  }
  if (window.__wa && window.__wa.ver === 7) { try { window.__wa.tick(); } catch (e) {} return; }

  var W = window.__wa = {
    ver: 7, seq: 0, mobile: true, showList: false, off: false,
    touched: [], found: 0, done: 0, failed: 0
  };

  // ---------------- 找消息 ----------------

  // 2026 年仍稳定的标记：每条文字消息都有 data-pre-plain-text 属性
  function messageEls(main) {
    var els = main.querySelectorAll('[data-pre-plain-text]');
    if (els.length) return els;
    return main.querySelectorAll('.message-in .copyable-text, .message-out .copyable-text');
  }

  // 判断是不是“我”发的消息
  function isOut(el, main) {
    var p = el;
    while (p && p !== main && p !== document.body) {
      var cl = p.classList;
      if (cl) {
        for (var i = 0; i < cl.length; i++) {
          if (cl[i].indexOf('message-out') >= 0) return true;
          if (cl[i].indexOf('message-in') >= 0) return false;
        }
      }
      var id = p.getAttribute && p.getAttribute('data-id');
      if (id) {
        if (id.indexOf('true_') === 0) return true;
        if (id.indexOf('false_') === 0) return false;
      }
      p = p.parentElement;
    }
    // 兜底：靠右的气泡是我发的
    var r = el.getBoundingClientRect(), m = main.getBoundingClientRect();
    return (r.left - m.left) > (m.right - r.right);
  }

  // 消息原文（排除我们自己插入的译文框）
  function textOf(el) {
    var t = '';
    for (var i = 0; i < el.childNodes.length; i++) {
      var n = el.childNodes[i];
      if (n.nodeType === 1 && n.classList && n.classList.contains('wa-tr')) continue;
      t += (n.nodeType === 1) ? (n.innerText || '') : (n.textContent || '');
    }
    return t.replace(/\s+$/g, '').trim();
  }

  function findBox(el) {
    for (var i = 0; i < el.children.length; i++) {
      if (el.children[i].classList.contains('wa-tr')) return el.children[i];
    }
    return null;
  }

  function styleBox(b, out) {
    var s = b.style;
    s.display = (W.off || b.getAttribute('data-skip')) ? 'none' : 'block';
    s.margin = '5px 0 2px';
    s.padding = '4px 8px';
    s.borderRadius = '6px';
    s.fontSize = '14px';
    s.lineHeight = '1.45';
    s.whiteSpace = 'pre-wrap';
    s.wordBreak = 'break-word';
    s.color = '#1f2328';
    s.background = out ? '#dbe8ff' : '#fff2c2';
    s.borderLeft = out ? '3px solid #3f7be0' : '3px solid #e0a800';
    s.userSelect = 'text';
  }

  W.scan = function () {
    var main = document.querySelector('#main');
    if (!main) { W.found = 0; return; }
    var els = messageEls(main);
    W.found = els.length;
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var t = textOf(el);
      if (!t) continue;
      var box = findBox(el);
      if (box && box.getAttribute('data-src') === t) continue;   // 已翻译过
      var out = isOut(el, main);
      if (!box) { box = document.createElement('div'); box.className = 'wa-tr'; el.appendChild(box); }
      box.removeAttribute('data-skip');
      box.setAttribute('data-src', t);
      var id = 'watr' + (++W.seq);
      box.id = id;
      box.textContent = '翻译中…';
      styleBox(box, out);
      box.style.opacity = '0.6';
      try { WaTr.translate(id, t, out); }
      catch (e) { box.textContent = '⚠ ' + e; box.style.opacity = '1'; }
    }
  };

  // App 回传译文；空字符串 = 本来就是我的语言，不显示
  window.__trSet = function (id, txt, failed) {
    var b = document.getElementById(id);
    if (!b) return;
    if (!txt) { b.setAttribute('data-skip', '1'); b.style.display = 'none'; return; }
    b.textContent = txt;
    b.style.opacity = '1';
    if (failed) W.failed++; else W.done++;
  };

  W.setOff = function (v) {
    W.off = !!v;
    document.querySelectorAll('.wa-tr').forEach(function (b) {
      b.style.display = (W.off || b.getAttribute('data-skip')) ? 'none' : 'block';
    });
    return W.off;
  };

  // ---------------- 输入框 ----------------

  W.input = function () {
    return document.querySelector('footer div[contenteditable="true"]') ||
      document.querySelector('#main div[contenteditable="true"][role="textbox"]') ||
      document.querySelector('#main div[contenteditable="true"]');
  };
  W.getInput = function () {
    var e = W.input();
    return e ? (e.innerText || '') : '__NOINPUT__';
  };
  function selectAllIn(e) {
    var sel = window.getSelection();
    var r = document.createRange();
    r.selectNodeContents(e);
    sel.removeAllRanges();
    sel.addRange(r);
  }
  function inputText(e) { return (e.innerText || '').replace(/\n+$/, '').trim(); }

  // 把文字写进 WhatsApp 输入框：先清空，再写入一次。
  // 注意：WhatsApp 的输入框要稍等一会儿才显示新内容，所以这里不立即检查（否则会重复写入），
  // 由 App 延迟读取后再确认。
  W.setInput = function (t) {
    t = t || '';
    var e = W.input();
    if (!e) return 'noinput';
    try { e.focus({ preventScroll: true }); } catch (x) { e.focus(); }
    selectAllIn(e);
    document.execCommand('delete', false, null);
    if (t) {
      selectAllIn(e);
      document.execCommand('insertText', false, t);
    }
    return 'sent';
  };

  // 备用写法：模拟粘贴（只在上面的方法没写进去时使用）
  W.pasteInput = function (t) {
    var e = W.input();
    if (!e) return 'noinput';
    try { e.focus({ preventScroll: true }); } catch (x) { e.focus(); }
    selectAllIn(e);
    var dt = new DataTransfer();
    dt.setData('text/plain', t || '');
    e.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    return 'sent';
  };

  // 点 WhatsApp 的发送按钮（找不到就模拟回车）
  W.send = function () {
    var b = document.querySelector('footer [data-icon*="send"], footer button[aria-label="Send"], footer button[aria-label="发送"]');
    if (b) { (b.closest('button') || b.closest('[role="button"]') || b).click(); return 'button'; }
    var e = W.input();
    if (!e) return 'noinput';
    e.focus();
    ['keydown', 'keypress', 'keyup'].forEach(function (tp) {
      e.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    });
    return 'enter';
  };

  // 当前聊天的标识（只用来判断有没有切换聊天，不外传）
  W.chatKey = function () {
    var h = document.querySelector('#main header span[dir="auto"]') || document.querySelector('#main header');
    var s = h ? (h.textContent || '') : '';
    var x = 0;
    for (var i = 0; i < s.length; i++) { x = ((x << 5) - x + s.charCodeAt(i)) | 0; }
    return document.querySelector('#main') ? String(x) : '';
  };

  // ---------------- 手机布局：列表 / 聊天 二选一全屏 ----------------

  function setS(el, k, v) {
    if (!el) return;
    if (W.touched.indexOf(el) < 0) W.touched.push(el);
    el.style[k] = v;
  }
  function resetAll() {
    W.touched.forEach(function (el) {
      ['display', 'flex', 'maxWidth', 'width', 'minWidth'].forEach(function (k) { el.style[k] = ''; });
    });
    W.touched = [];
  }
  function columns() {
    var side = document.querySelector('#side');
    if (!side) return null;
    var main = document.querySelector('#main');
    if (main) {
      var row = side;
      while (row && !row.contains(main)) row = row.parentElement;
      if (!row) return null;
      var col = side; while (col.parentElement !== row) col = col.parentElement;
      var mainCol = main; while (mainCol.parentElement !== row) mainCol = mainCol.parentElement;
      W.col = col;
      return { col: col, row: row, mainCol: mainCol };
    }
    if (W.col && document.contains(W.col) && W.col.contains(side)) return { col: W.col, row: W.col.parentElement };
    var c = side;
    while (c.parentElement && c.parentElement.childElementCount < 2) c = c.parentElement;
    return { col: c, row: c.parentElement };
  }
  W.layout = function () {
    resetAll();
    if (!W.mobile) return;
    var c = columns();
    if (!c || !c.row || c.row === document.body || c.row === document.documentElement) return;
    var main = document.querySelector('#main');
    var showChat = !!main && !W.showList;
    var e = c.col;
    while (e && e !== document.body) { setS(e, 'minWidth', '0'); e = e.parentElement; }
    Array.prototype.forEach.call(c.row.children, function (ch) {
      if (ch === c.col) {
        if (showChat) setS(ch, 'display', 'none');
        else { setS(ch, 'flex', '1 1 100%'); setS(ch, 'maxWidth', '100%'); setS(ch, 'width', '100%'); }
      } else if (showChat) {
        if (ch === c.mainCol) { setS(ch, 'flex', '1 1 100%'); setS(ch, 'width', '100%'); }
        setS(ch, 'maxWidth', '100%'); setS(ch, 'minWidth', '0');
      } else {
        setS(ch, 'display', 'none');
      }
    });
    if (main) { var m = main; while (m && m !== c.row) { setS(m, 'minWidth', '0'); m = m.parentElement; } }
  };
  W.setMobile = function (on) {
    W.mobile = !!on;
    var v = document.getElementById('wa-vp');
    if (v) v.content = on ? 'width=device-width,initial-scale=1,maximum-scale=3' : 'width=1100';
    W.layout();
  };
  W.back = function () {
    if (W.mobile && document.querySelector('#main') && !W.showList) { W.showList = true; W.layout(); return true; }
    return false;
  };
  W.list = function () { W.showList = true; W.layout(); };

  // ---------------- 状态 / 诊断（不含聊天内容） ----------------

  W.stats = function () {
    var main = document.querySelector('#main');
    return JSON.stringify({
      side: !!document.querySelector('#side'),
      main: !!main,
      found: W.found,
      done: W.done,
      failed: W.failed,
      boxes: document.querySelectorAll('.wa-tr').length,
      prePlain: document.querySelectorAll('[data-pre-plain-text]').length,
      msgIn: document.querySelectorAll('[class*="message-in"]').length,
      msgOut: document.querySelectorAll('[class*="message-out"]').length,
      dataId: main ? main.querySelectorAll('[data-id]').length : 0,
      rows: main ? main.querySelectorAll('[role="row"]').length : 0,
      dirSpans: main ? main.querySelectorAll('span[dir]').length : 0,
      input: !!W.input(),
      chat: W.chatKey(),
      bridge: typeof WaTr,
      ver: W.ver
    });
  };

  W.tick = function () { W.scan(); W.layout(); };

  // ---------------- 启动 ----------------

  var vp = document.getElementById('wa-vp');
  if (!vp) {
    vp = document.createElement('meta');
    vp.name = 'viewport'; vp.id = 'wa-vp';
    vp.content = 'width=device-width,initial-scale=1,maximum-scale=3';
    (document.head || document.documentElement).appendChild(vp);
  }

  document.addEventListener('click', function (e) {
    var side = document.querySelector('#side');
    if (side && side.contains(e.target)) { W.showList = false; setTimeout(W.layout, 300); }
  }, true);

  var timer = null;
  new MutationObserver(function (muts) {
    // 忽略我们自己改译文框引起的变化
    var ours = true;
    for (var i = 0; i < muts.length; i++) {
      var t = muts[i].target;
      if (!(t && t.classList && t.classList.contains('wa-tr'))) { ours = false; break; }
    }
    if (ours) return;
    clearTimeout(timer);
    timer = setTimeout(function () { try { W.tick(); } catch (e) {} }, 250);
  }).observe(document.body, { childList: true, subtree: true });

  W.tick();
})();
