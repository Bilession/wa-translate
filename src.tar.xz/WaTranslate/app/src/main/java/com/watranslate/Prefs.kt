package com.watranslate

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("wa_translate", Context.MODE_PRIVATE)

    fun myLang(c: Context): String = sp(c).getString("my", "zh") ?: "zh"
    fun setMyLang(c: Context, v: String) = sp(c).edit().putString("my", v).apply()

    fun theirLang(c: Context): String = sp(c).getString("their", "en") ?: "en"
    fun setTheirLang(c: Context, v: String) = sp(c).edit().putString("their", v).apply()

    fun autoDetect(c: Context): Boolean = sp(c).getBoolean("auto", true)
    fun setAutoDetect(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
}

object Langs {
    // 代码均为 ML Kit TranslateLanguage 支持的语言
    val ALL = listOf(
        "zh" to "中文", "en" to "英语 English", "es" to "西班牙语 Español",
        "pt" to "葡萄牙语 Português", "ar" to "阿拉伯语 العربية", "ru" to "俄语 Русский",
        "fr" to "法语 Français", "de" to "德语 Deutsch", "it" to "意大利语 Italiano",
        "ja" to "日语 日本語", "ko" to "韩语 한국어", "vi" to "越南语 Tiếng Việt",
        "th" to "泰语 ไทย", "id" to "印尼语 Indonesia", "ms" to "马来语 Melayu",
        "tl" to "菲律宾语 Tagalog", "hi" to "印地语 हिन्दी", "ur" to "乌尔都语 اردو",
        "bn" to "孟加拉语 বাংলা", "fa" to "波斯语 فارسی", "tr" to "土耳其语 Türkçe",
        "nl" to "荷兰语 Nederlands", "pl" to "波兰语 Polski", "uk" to "乌克兰语 Українська",
        "he" to "希伯来语 עברית", "sw" to "斯瓦希里语 Kiswahili"
    )

    fun name(code: String): String = ALL.firstOrNull { it.first == code }?.second ?: code
    fun indexOf(code: String): Int = ALL.indexOfFirst { it.first == code }.coerceAtLeast(0)
}
