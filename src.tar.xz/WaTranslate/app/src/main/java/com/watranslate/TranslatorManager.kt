package com.watranslate

import android.util.LruCache
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * 封装 ML Kit 离线翻译。模型下载后完全在手机本地运行，免费、无 token 消耗。
 * 所有回调都在主线程。
 */
class TranslatorManager {
    private val translators = HashMap<String, Translator>()
    private val cache = LruCache<String, String>(800)
    private val identifier = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.45f).build()
    )

    /** 翻译 src → tgt。失败回调 null。 */
    fun translate(text: String, src: String, tgt: String, cb: (String?) -> Unit) {
        if (src == tgt) { cb(text); return }
        val key = "$src|$tgt|$text"
        cache.get(key)?.let { cb(it); return }
        val t = translators.getOrPut("$src|$tgt") {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build()
            )
        }
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .continueWithTask<String> { task ->
                if (task.isSuccessful) t.translate(text)
                else Tasks.forException<String>(task.exception ?: Exception("model download failed"))
            }
            .addOnSuccessListener { r -> cache.put(key, r); cb(r) }
            .addOnFailureListener { cb(null) }
    }

    /**
     * 自动识别源语言后翻译成 target。
     * cb(译文, 识别出的语言)；如果原文本身就是 target 语言，译文返回 ""（表示无需翻译）。
     */
    fun detectAndTranslate(text: String, target: String, fallbackSrc: String, cb: (String?, String) -> Unit) {
        identifier.identifyLanguage(text)
            .addOnSuccessListener { tag ->
                val src = if (tag == "und") fallbackSrc
                else TranslateLanguage.fromLanguageTag(tag) ?: fallbackSrc
                if (src == target) cb("", src)
                else translate(text, src, target) { cb(it, src) }
            }
            .addOnFailureListener {
                translate(text, fallbackSrc, target) { cb(it, fallbackSrc) }
            }
    }

    private val langCache = LruCache<String, String>(800)

    /** 只识别语言（本地运行），失败或不确定时返回 fallback。 */
    fun detectLanguage(text: String, fallback: String, cb: (String) -> Unit) {
        langCache.get(text)?.let { cb(it); return }
        identifier.identifyLanguage(text)
            .addOnSuccessListener { tag ->
                val l = if (tag == "und") fallback else TranslateLanguage.fromLanguageTag(tag) ?: fallback
                if (tag != "und") langCache.put(text, l)
                cb(l)
            }
            .addOnFailureListener { cb(fallback) }
    }

    fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
        identifier.close()
    }
}
