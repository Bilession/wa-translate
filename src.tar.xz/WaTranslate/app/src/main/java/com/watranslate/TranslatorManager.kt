package com.watranslate

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** 翻译结果：译文、识别出的源语言、实际使用的引擎 */
data class TrResult(val text: String, val src: String, val engine: String)

/**
 * 翻译引擎（全部免费、无需 API Key、不消耗 token）：
 *  - 谷歌翻译（默认）
 *  - 微软翻译（谷歌不通时自动备用）
 * 语言识别也由翻译接口完成。所有回调都在主线程。
 */
class TranslatorManager(private val ctx: Context) {
    private val io = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())
    private val cache = LruCache<String, TrResult>(1500)

    /** 自动识别源语言，翻译成 tgt。失败回调 null。 */
    fun translateAuto(text: String, tgt: String, cb: (TrResult?) -> Unit) = run(text, null, tgt, cb)

    /** 指定源语言翻译。失败回调 null。 */
    fun translate(text: String, src: String, tgt: String, cb: (String?) -> Unit) {
        if (src == tgt) { cb(text); return }
        run(text, src, tgt) { cb(it?.text) }
    }

    private fun run(text: String, src: String?, tgt: String, cb: (TrResult?) -> Unit) {
        val engine = Prefs.engine(ctx)
        val key = "$engine|${src ?: "auto"}|$tgt|$text"
        cache.get(key)?.let { cb(it); return }
        val order = if (engine == "microsoft") listOf("microsoft", "google") else listOf("google", "microsoft")
        io.execute {
            var r: TrResult? = null
            for (e in order) {
                r = try {
                    if (e == "google") google(text, src, tgt) else microsoft(text, src, tgt)
                } catch (ex: Exception) { null }
                if (r != null && r.text.isNotBlank()) break
                r = null
            }
            val result = r
            main.post {
                if (result != null) cache.put(key, result)
                cb(result)
            }
        }
    }

    // ---------------- 语言代码 ----------------

    /** 把各家接口返回的语言代码统一成 App 内部代码（zh / en / es …） */
    fun norm(code: String?): String {
        val c = (code ?: "").trim().lowercase()
        return when {
            c.isEmpty() -> ""
            c.startsWith("zh") -> "zh"
            c == "iw" -> "he"
            c == "fil" -> "tl"
            else -> c.substringBefore('-')
        }
    }

    private fun gCode(l: String) = when (l) { "zh" -> "zh-CN"; "he" -> "iw"; else -> l }
    private fun msCode(l: String) = when (l) { "zh" -> "zh-Hans"; "tl" -> "fil"; else -> l }

    // ---------------- 谷歌翻译（免费网页接口） ----------------

    private fun google(text: String, src: String?, tgt: String): TrResult? {
        val base = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t" +
                "&sl=${src?.let { gCode(it) } ?: "auto"}&tl=${gCode(tgt)}"
        val q = URLEncoder.encode(text, "UTF-8")
        val body = if (q.length < 1800) httpGet("$base&q=$q", emptyMap())
        else httpPost(base, "q=$q", "application/x-www-form-urlencoded;charset=UTF-8", emptyMap())
        val arr = JSONArray(body)
        val segs = arr.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until segs.length()) {
            val seg = segs.optJSONArray(i) ?: continue
            if (seg.isNull(0)) continue
            sb.append(seg.getString(0))
        }
        val detected = src ?: norm(arr.optString(2))
        return TrResult(sb.toString().trim(), detected, "谷歌")
    }

    // ---------------- 微软翻译（Edge 浏览器内置的免费接口） ----------------

    @Volatile private var msToken: String? = null
    @Volatile private var msTokenAt = 0L

    private fun microsoft(text: String, src: String?, tgt: String): TrResult? {
        synchronized(this) {
            val now = System.currentTimeMillis()
            if (msToken == null || now - msTokenAt > 8 * 60 * 1000) {
                msToken = httpGet("https://edge.microsoft.com/translate/auth", emptyMap()).trim()
                msTokenAt = now
            }
        }
        var url = "https://api-edge.cognitive.microsofttranslator.com/translate?api-version=3.0&to=${msCode(tgt)}"
        if (src != null) url += "&from=${msCode(src)}"
        val payload = JSONArray().put(JSONObject().put("Text", text)).toString()
        val resp = httpPost(url, payload, "application/json", mapOf("Authorization" to "Bearer $msToken"))
        val o = JSONArray(resp).getJSONObject(0)
        val t = o.getJSONArray("translations").getJSONObject(0).getString("text").trim()
        val detected = src ?: norm(o.optJSONObject("detectedLanguage")?.optString("language"))
        return TrResult(t, detected, "微软")
    }

    // ---------------- 网络 ----------------

    private fun httpGet(url: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000; c.readTimeout = 10000
            c.setRequestProperty("User-Agent", UA)
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).readText()
        } finally { c.disconnect() }
    }

    private fun httpPost(url: String, body: String, type: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000; c.readTimeout = 10000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", type)
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).readText()
        } finally { c.disconnect() }
    }

    fun close() { io.shutdown() }

    companion object {
        const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
    }
}
