package com.watranslate

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * 翻译引擎（全部免费、无需 API Key、不消耗 token）：
 *  - 谷歌翻译（在线，质量最好，默认）
 *  - 微软翻译（在线，谷歌不通时自动备用）
 *  - ML Kit 离线翻译（以上都失败时兜底）
 * 所有回调都在主线程。
 */
class TranslatorManager(private val ctx: Context) {
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())
    private val translators = HashMap<String, Translator>()
    private val cache = LruCache<String, String>(1000)
    private val identifier = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.45f).build()
    )

    /** 翻译 src → tgt。失败回调 null。 */
    fun translate(text: String, src: String, tgt: String, cb: (String?) -> Unit) {
        if (src == tgt) { cb(text); return }
        val engine = Prefs.engine(ctx)
        val key = "$engine|$src|$tgt|$text"
        cache.get(key)?.let { cb(it); return }

        val chain: List<(String, String, String) -> String?> = when (engine) {
            "google" -> listOf(this::google, this::microsoft)
            "microsoft" -> listOf(this::microsoft, this::google)
            else -> emptyList()
        }
        if (chain.isEmpty()) {
            offline(text, src, tgt) { r -> if (r != null) cache.put(key, r); cb(r) }
            return
        }
        io.execute {
            var r: String? = null
            for (f in chain) {
                r = try { f(text, src, tgt) } catch (e: Exception) { null }
                if (!r.isNullOrBlank()) break
            }
            main.post {
                if (!r.isNullOrBlank()) { cache.put(key, r); cb(r) }
                else offline(text, src, tgt) { o -> if (o != null) cache.put(key, o); cb(o) }
            }
        }
    }

    // ---------------- 谷歌翻译（免费网页接口） ----------------

    private fun gCode(l: String) = when (l) { "zh" -> "zh-CN"; "he" -> "iw"; else -> l }

    private fun google(text: String, src: String, tgt: String): String? {
        val base = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t" +
                "&sl=${gCode(src)}&tl=${gCode(tgt)}"
        val q = URLEncoder.encode(text, "UTF-8")
        val body = if (q.length < 1800) httpGet("$base&q=$q", emptyMap())
        else httpPost(base, "q=$q", "application/x-www-form-urlencoded;charset=UTF-8", emptyMap())
        val segs = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until segs.length()) {
            val seg = segs.optJSONArray(i) ?: continue
            if (seg.isNull(0)) continue
            sb.append(seg.getString(0))
        }
        return sb.toString().trim()
    }

    // ---------------- 微软翻译（Edge 浏览器内置的免费接口） ----------------

    @Volatile private var msToken: String? = null
    @Volatile private var msTokenAt = 0L

    private fun msCode(l: String) = when (l) { "zh" -> "zh-Hans"; "tl" -> "fil"; else -> l }

    private fun microsoft(text: String, src: String, tgt: String): String? {
        synchronized(this) {
            val now = System.currentTimeMillis()
            if (msToken == null || now - msTokenAt > 8 * 60 * 1000) {
                msToken = httpGet("https://edge.microsoft.com/translate/auth", emptyMap()).trim()
                msTokenAt = now
            }
        }
        val url = "https://api-edge.cognitive.microsofttranslator.com/translate?api-version=3.0" +
                "&from=${msCode(src)}&to=${msCode(tgt)}"
        val payload = JSONArray().put(JSONObject().put("Text", text)).toString()
        val resp = httpPost(url, payload, "application/json", mapOf("Authorization" to "Bearer $msToken"))
        return JSONArray(resp).getJSONObject(0).getJSONArray("translations")
            .getJSONObject(0).getString("text").trim()
    }

    // ---------------- ML Kit 离线（兜底） ----------------

    private fun offline(text: String, src: String, tgt: String, cb: (String?) -> Unit) {
        val t = translators.getOrPut("$src|$tgt") {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build()
            )
        }
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .continueWithTask<String> { task ->
                if (task.isSuccessful) t.translate(text)
                else Tasks.forException<String>(task.exception ?: Exception("model download failed"))
            }
            .addOnSuccessListener { r -> cb(r) }
            .addOnFailureListener { cb(null) }
    }

    // ---------------- 语言识别（本地运行） ----------------

    private val langCache = LruCache<String, String>(1000)

    /** 只识别语言，失败或不确定时返回 fallback。 */
    fun detectLanguage(text: String, fallback: String, cb: (String) -> Unit) {
        langCache.get(text)?.let { cb(it); return }
        identifier.identifyLanguage(text)
            .addOnSuccessListener { tag ->
                val l = if (tag == "und") fallback else TranslateLanguage.fromLanguageTag(tag) ?: fallback
                if (tag != "und") langCache.put(text, l)
                cb(l)
            }
            .addOnFailureListener { cb(fallback) }
    }

    // ---------------- 网络 ----------------

    private fun httpGet(url: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 7000; c.readTimeout = 10000
            c.setRequestProperty("User-Agent", UA)
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).readText()
        } finally { c.disconnect() }
    }

    private fun httpPost(url: String, body: String, type: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 7000; c.readTimeout = 10000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", type)
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).readText()
        } finally { c.disconnect() }
    }

    fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
        identifier.close()
        io.shutdown()
    }

    companion object {
        const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
    }
}
