package com.watranslate

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.Spinner
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var modelStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        modelStatus = findViewById(R.id.modelStatus)

        findViewById<Button>(R.id.btnOpenWeb).setOnClickListener {
            startActivity(Intent(this, WaWebActivity::class.java))
        }
        findViewById<Button>(R.id.btnOpenWa).setOnClickListener {
            val i = packageManager.getLaunchIntentForPackage("com.whatsapp")
                ?: packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
            if (i != null) startActivity(i)
            else android.widget.Toast.makeText(this, "没有找到 WhatsApp", android.widget.Toast.LENGTH_SHORT).show()
        }

        val engines = listOf("google" to "谷歌翻译（推荐，质量最好）", "microsoft" to "微软翻译", "offline" to "离线翻译（不联网，质量一般）")
        val spEngine = findViewById<Spinner>(R.id.spEngine)
        spEngine.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, engines.map { it.second })
        spEngine.setSelection(engines.indexOfFirst { it.first == Prefs.engine(this) }.coerceAtLeast(0))
        spEngine.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Prefs.setEngine(this@MainActivity, engines[pos].first)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnA11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val names = Langs.ALL.map { it.second }
        setupSpinner(findViewById(R.id.spMy), names, Prefs.myLang(this)) { Prefs.setMyLang(this, it) }
        setupSpinner(findViewById(R.id.spTheir), names, Prefs.theirLang(this)) { Prefs.setTheirLang(this, it) }

        findViewById<CheckBox>(R.id.cbAuto).apply {
            isChecked = Prefs.autoDetect(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setAutoDetect(this@MainActivity, v) }
        }
        findViewById<CheckBox>(R.id.cbEnabled).apply {
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this@MainActivity, v) }
        }
        findViewById<Button>(R.id.btnDownload).setOnClickListener { downloadModels() }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshModels()
    }

    private fun setupSpinner(sp: Spinner, names: List<String>, current: String, onPick: (String) -> Unit) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(Langs.indexOf(current))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                onPick(Langs.ALL[pos].first)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun isServiceOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(this, WaTranslateService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun refreshStatus() {
        if (isServiceOn()) {
            status.text = "✅ 无障碍服务已开启，打开 WhatsApp 聊天即可使用"
            status.setBackgroundColor(Color.parseColor("#E3F6E8"))
        } else {
            status.text = "⚠️ 无障碍服务未开启，请点击下方按钮，在列表中找到“WA实时翻译”并打开"
            status.setBackgroundColor(Color.parseColor("#FFF1D6"))
        }
    }

    private fun downloadModels() {
        val langs = setOf(Prefs.myLang(this), Prefs.theirLang(this)).filter { it != TranslateLanguage.ENGLISH }
        if (langs.isEmpty()) { modelStatus.text = "英语模型是内置的，无需下载"; return }
        modelStatus.text = "正在下载：${langs.joinToString("、") { Langs.name(it) }} …（请保持联网）"
        val mgr = RemoteModelManager.getInstance()
        var left = langs.size
        var failed = false
        for (l in langs) {
            mgr.download(TranslateRemoteModel.Builder(l).build(), DownloadConditions.Builder().build())
                .addOnFailureListener { failed = true }
                .addOnCompleteListener {
                    left--
                    if (left == 0) {
                        if (failed) modelStatus.text = "下载失败，请检查网络后重试（需要能访问 Google 服务）"
                        else refreshModels()
                    }
                }
        }
    }

    private fun refreshModels() {
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { models ->
                val got = models.map { it.language }.toSet()
                val need = setOf(Prefs.myLang(this), Prefs.theirLang(this)) - got
                val names = got.joinToString("、") { Langs.name(it) }.ifEmpty { "无" }
                modelStatus.text = if (need.isEmpty()) "✅ 模型已就绪（已下载：$names）"
                else "已下载：$names\n还需要：${need.joinToString("、") { Langs.name(it) }}"
            }
    }
}
