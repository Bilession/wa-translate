package com.watranslate

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.Spinner

/** 翻译设置 */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val names = Langs.ALL.map { it.second }
        setupSpinner(findViewById(R.id.spMy), names, Langs.indexOf(Prefs.myLang(this))) {
            Prefs.setMyLang(this, Langs.ALL[it].first)
        }
        setupSpinner(findViewById(R.id.spTheir), names, Langs.indexOf(Prefs.theirLang(this))) {
            Prefs.setTheirLang(this, Langs.ALL[it].first)
        }
        val engines = listOf("google" to "谷歌翻译（推荐）", "microsoft" to "微软翻译")
        setupSpinner(findViewById(R.id.spEngine), engines.map { it.second },
            engines.indexOfFirst { it.first == Prefs.engine(this) }.coerceAtLeast(0)) {
            Prefs.setEngine(this, engines[it].first)
        }
        findViewById<CheckBox>(R.id.cbAuto).apply {
            isChecked = Prefs.autoDetect(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setAutoDetect(this@MainActivity, v) }
        }
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun setupSpinner(sp: Spinner, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(selected)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = onPick(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
}
