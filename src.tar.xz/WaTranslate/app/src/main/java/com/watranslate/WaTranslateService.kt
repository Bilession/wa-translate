package com.watranslate

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 像插件一样“嵌入” WhatsApp 的双语翻译：
 *  1) 聊天界面里每一条消息（对方的、自己的）下方直接显示译文，形成“原文 + 译文”双语；
 *     对方消息 → 译成我的语言；我发出的消息 → 若是我的语言则译成对方语言，否则译成我的语言。
 *  2) 悬浮“译”按钮：把输入框内容翻译成对方语言后替换，再按发送。
 *  全部使用 ML Kit 手机本地离线翻译，免费、不消耗 token。
 */
class WaTranslateService : AccessibilityService() {

    companion object {
        private val WA_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
        // WhatsApp 界面控件 ID（如 WhatsApp 大改版导致失效，改这里即可）
        private val MESSAGE_IDS = listOf("message_text")
        private val ENTRY_IDS = listOf("entry")
        private const val ERR = "\u0000ERR"
        private const val SKIP = ""
    }

    private data class Msg(val text: String, val rect: Rect, val bubble: Rect, val outgoing: Boolean)

    private lateinit var tm: TranslatorManager
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val scanRunnable = Runnable { scan() }

    // 悬浮“译”按钮
    private var bubble: TextView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams

    // 全屏、不可触摸的译文图层（只负责画译文标签，不挡操作）
    private var layer: FrameLayout? = null
    private lateinit var layerParams: WindowManager.LayoutParams
    // 每条译文是一个独立的小悬浮窗：可以点击展开/收起，长按复制
    private val labelPool = ArrayList<TextView>()
    private val labelParams = ArrayList<WindowManager.LayoutParams>()
    private val expanded = HashSet<String>()

    private var overlaysShown = false
    private var inlineOn = true
    private var lastMsgs: List<Msg> = emptyList()
    private var lastClip = Rect()

    private val results = LruCache<String, String>(600)
    private val pending = HashSet<String>()
    private var detectedTheirLang: String? = null

    private var lastOriginal: String? = null
    private var lastTranslated: String? = null

    // ---------------- 生命周期 ----------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        tm = TranslatorManager()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlays()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        val isWa = pkg in WA_PACKAGES
        if (!isWa && !(overlaysShown && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)) return

        if (isWa && event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            // 滚动时先隐藏译文，停下后重新对齐，避免标签“漂”
            hideLabels()
            handler.removeCallbacks(scanRunnable)
            handler.postDelayed(scanRunnable, 160)
            return
        }
        handler.removeCallbacks(scanRunnable)
        handler.postDelayed(scanRunnable, 120)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        setOverlaysVisible(false)
        if (::tm.isInitialized) tm.close()
        super.onDestroy()
    }

    // ---------------- 读取聊天画面 ----------------

    private fun scan() {
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()
        if (root == null || pkg == null || pkg !in WA_PACKAGES || !Prefs.enabled(this)) {
            setOverlaysVisible(false); return
        }
        val entry = findEntry(root, pkg)
        if (entry == null) { setOverlaysVisible(false); return }   // 不在聊天页
        setOverlaysVisible(true)

        val screenW = resources.displayMetrics.widthPixels
        val msgs = ArrayList<Msg>()
        var listNode: AccessibilityNodeInfo? = null
        for (id in MESSAGE_IDS) {
            for (n in root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")) {
                val t = n.text?.toString()?.trim()
                if (t.isNullOrEmpty()) continue
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.isEmpty) continue
                msgs.add(Msg(t, r, bubbleRect(n, r, screenW), outgoing = r.left > screenW - r.right))
                if (listNode == null) listNode = findScrollParent(n)
            }
        }

        // 译文只画在聊天列表区域内（不盖住顶栏和输入框）
        val clip = Rect()
        if (listNode != null) listNode.getBoundsInScreen(clip)
        if (clip.isEmpty) {
            val e = Rect(); entry.getBoundsInScreen(e)
            clip.set(0, dp(80), screenW, e.top - dp(8))
        }

        msgs.sortBy { it.rect.top }
        requestTranslations(msgs)
        lastMsgs = msgs
        lastClip = clip
        renderLabels()
    }

    /** 找到消息所在的气泡范围（包含引用、发送者名字、时间），用来避免译文盖住下一条消息 */
    private fun bubbleRect(n: AccessibilityNodeInfo, text: Rect, screenW: Int): Rect {
        val best = Rect(text)
        var p = n.parent
        var d = 0
        while (p != null && d < 5) {
            val r = Rect()
            p.getBoundsInScreen(r)
            if (r.width() >= screenW * 0.97) break     // 已经到整行容器了
            if (r.contains(text)) best.set(r)
            p = p.parent
            d++
        }
        return best
    }

    private fun findScrollParent(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var p = n.parent
        var depth = 0
        while (p != null && depth < 12) {
            val cls = p.className?.toString() ?: ""
            if (p.isScrollable || cls.endsWith("RecyclerView") || cls.endsWith("ListView")) return p
            p = p.parent
            depth++
        }
        return null
    }

    // ---------------- 翻译 ----------------

    private fun keyOf(m: Msg) = "${Prefs.myLang(this)}|${m.outgoing}|${m.text}"

    private fun requestTranslations(msgs: List<Msg>) {
        val my = Prefs.myLang(this)
        val theirSetting = Prefs.theirLang(this)
        for (m in msgs) {
            val key = keyOf(m)
            if (results.get(key) != null || !pending.add(key)) continue
            val done = { r: String? ->
                pending.remove(key)
                results.put(key, r ?: ERR)
                renderLabels()
            }
            tm.detectLanguage(m.text, theirSetting) { src ->
                if (!m.outgoing) {
                    // 对方的消息：不是我的语言就译成我的语言
                    if (src == my) done(SKIP)
                    else {
                        detectedTheirLang = src
                        tm.translate(m.text, src, my) { done(it) }
                    }
                } else {
                    // 我发的消息：我的语言 → 译成对方语言；外语 → 译回我的语言（看自己发了什么）
                    if (src == my) {
                        val tgt = outgoingTarget()
                        if (tgt == my) done(SKIP) else tm.translate(m.text, my, tgt) { done(it) }
                    } else tm.translate(m.text, src, my) { done(it) }
                }
            }
        }
    }

    private fun outgoingTarget(): String =
        if (Prefs.autoDetect(this)) detectedTheirLang ?: Prefs.theirLang(this) else Prefs.theirLang(this)

    // ---------------- 画译文标签 ----------------

    private fun hideLabels() {
        for (tv in labelPool) if (tv.isAttachedToWindow) tv.visibility = View.INVISIBLE
    }

    private fun renderLabels() {
        val lay = layer ?: return
        if (!overlaysShown || !lay.isAttachedToWindow) return
        if (!inlineOn) { removeLabelsFrom(0); return }

        // 悬浮窗坐标系相对屏幕的偏移（不同机型状态栏处理不同）
        val origin = IntArray(2)
        lay.getLocationOnScreen(origin)

        val clip = lastClip
        val screenW = resources.displayMetrics.widthPixels
        val msgs = lastMsgs
        var used = 0
        for ((i, m) in msgs.withIndex()) {
            val key = keyOf(m)
            val r = results.get(key)
            if (r == SKIP) continue
            val top = m.rect.bottom + dp(1)
            if (top < clip.top || top > clip.bottom - dp(18)) continue

            // 能用的高度：到下一条消息气泡的顶部为止（不盖住下一条消息）
            val nextTop = if (i + 1 < msgs.size) msgs[i + 1].bubble.top else clip.bottom
            val avail = min(nextTop, clip.bottom) - top - dp(1)

            val text = when (r) {
                null -> "…"
                ERR -> "⚠ 翻译失败：请在 App 里下载语言模型"
                else -> r
            }
            val tv = labelAt(used)
            val lp = labelParams[used]
            used++

            tv.text = text
            styleLabel(tv, m.outgoing)
            val isOpen = key in expanded
            val lineH = tv.lineHeight
            val fitLines = max(1, (avail - dp(7)) / max(1, lineH))
            tv.maxLines = if (isOpen) 20 else fitLines
            tv.maxWidth = min(max(m.bubble.width() - dp(12), dp(140)), screenW - dp(24))
            tv.tag = key
            tv.setOnClickListener {
                if (!expanded.remove(key)) expanded.add(key)
                renderLabels()
            }
            tv.setOnLongClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("译文", tv.text))
                toast("已复制译文")
                true
            }

            // 与消息文字左对齐，短译文不会盖到右下角的时间和已读勾
            lp.x = max(dp(4), m.rect.left - dp(2)) - origin[0]
            lp.y = top - origin[1]
            try {
                if (tv.isAttachedToWindow) wm.updateViewLayout(tv, lp) else wm.addView(tv, lp)
            } catch (_: Exception) {}
            tv.visibility = View.VISIBLE
        }
        removeLabelsFrom(used)
    }

    private fun removeLabelsFrom(from: Int) {
        for (i in from until labelPool.size) {
            val tv = labelPool[i]
            try { if (tv.isAttachedToWindow) wm.removeView(tv) } catch (_: Exception) {}
        }
    }

    private fun labelAt(i: Int): TextView {
        while (labelPool.size <= i) {
            val tv = TextView(this).apply {
                textSize = 13.5f
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(7), dp(2), dp(7), dp(3))
                setLineSpacing(0f, 1.0f)
                elevation = dp(1).toFloat()
            }
            labelPool.add(tv)
            labelParams.add(WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START })
        }
        return labelPool[i]
    }

    private fun styleLabel(tv: TextView, outgoing: Boolean) {
        val bg = if (outgoing) "#F5E3F0FF" else "#F5FFF6D6"
        val stroke = if (outgoing) "#8FA6C8F0" else "#8FE6C55A"
        tv.background = GradientDrawable().apply {
            cornerRadius = dp(7).toFloat()
            setColor(Color.parseColor(bg))
            setStroke(dp(1), Color.parseColor(stroke))
        }
        tv.setTextColor(Color.parseColor("#1F2328"))
    }

    // ---------------- 发送方向：翻译输入框 ----------------

    private fun findEntry(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        for (id in ENTRY_IDS) {
            root.findAccessibilityNodeInfosByViewId("$pkg:id/$id").firstOrNull()?.let { return it }
        }
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
    }

    private fun currentEntry(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: return null
        if (pkg !in WA_PACKAGES) return null
        return findEntry(root, pkg)
    }

    private fun onBubbleTap() {
        val entry = currentEntry() ?: run { toast("请先打开一个 WhatsApp 聊天"); return }
        val showingHint = Build.VERSION.SDK_INT >= 26 && entry.isShowingHintText
        val text = if (showingHint) "" else entry.text?.toString().orEmpty()
        if (text.isBlank()) { toast("先在输入框里打字，再点“译”"); return }

        if (text == lastTranslated && lastOriginal != null) {
            setEntryText(lastOriginal!!)
            lastTranslated = null
            toast("已还原原文")
            return
        }
        val src = Prefs.myLang(this)
        val tgt = outgoingTarget()
        if (src == tgt) { toast("我的语言和对方语言相同，请在 App 里设置"); return }

        bubble?.text = "…"
        tm.translate(text.trim(), src, tgt) { r ->
            bubble?.text = "译"
            if (r == null) {
                toast("翻译失败：请在 App 里下载${Langs.name(tgt)}模型")
                return@translate
            }
            lastOriginal = text
            lastTranslated = r
            setEntryText(r)
        }
    }

    private fun setEntryText(s: String) {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        }
        currentEntry()?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun toggleInline() {
        inlineOn = !inlineOn
        toast(if (inlineOn) "已显示双语译文" else "已隐藏译文")
        renderLabels()
    }

    // ---------------- 悬浮窗 ----------------

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun createOverlays() {
        // 译文图层：全屏、不可触摸，触摸直接穿透到 WhatsApp
        // 透明的全屏定位层：只用来换算坐标，不显示内容、不拦截触摸
        layer = FrameLayout(this)
        layerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        // 悬浮“译”按钮
        bubble = TextView(this).apply {
            text = "译"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E62F6FED"))
            }
            elevation = dp(4).toFloat()
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(48), dp(48),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(6)
            y = (resources.displayMetrics.heightPixels * 0.55).toInt()
        }
        bubble!!.setOnTouchListener(BubbleTouch())
    }

    private fun setOverlaysVisible(v: Boolean) {
        if (v == overlaysShown) return
        overlaysShown = v
        try {
            if (v) {
                layer?.let { wm.addView(it, layerParams) }
                bubble?.let { wm.addView(it, bubbleParams) }
                // 定位层挂上窗口后再画第一次译文
                handler.postDelayed({ renderLabels() }, 150)
            } else {
                removeLabelsFrom(0)
                layer?.let { if (it.isAttachedToWindow) wm.removeView(it) }
                bubble?.let { if (it.isAttachedToWindow) wm.removeView(it) }
            }
        } catch (_: Exception) {
        }
    }

    private inner class BubbleTouch : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false
        private var downAt = 0L

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = bubbleParams.x; startY = bubbleParams.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    downAt = SystemClock.uptimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        bubbleParams.x = startX - dx.toInt()   // Gravity.END：x 从右边算
                        bubbleParams.y = startY + dy.toInt()
                        try { wm.updateViewLayout(v, bubbleParams) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (SystemClock.uptimeMillis() - downAt > 500) toggleInline() else onBubbleTap()
                }
            }
            return true
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
