package com.watranslate

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * 无障碍服务：
 *  1) 读取 WhatsApp 聊天界面里对方发来的消息，离线翻译后显示在顶部悬浮译文条；
 *  2) 悬浮“译”按钮：把输入框里的内容翻译成对方语言并替换，用户自己按发送。
 */
class WaTranslateService : AccessibilityService() {

    companion object {
        private val WA_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
        // WhatsApp 界面控件 ID（如 WhatsApp 大改版导致失效，改这里即可）
        private val MESSAGE_IDS = listOf("message_text")
        private val ENTRY_IDS = listOf("entry")
        private const val MAX_ROWS = 4
        private const val ERR = "\u0000ERR"
    }

    private lateinit var tm: TranslatorManager
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val scanRunnable = Runnable { scan() }

    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelHeader: TextView? = null
    private var panelList: LinearLayout? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private var overlaysShown = false
    private var panelCollapsed = false

    private val results = LruCache<String, String>(400)   // key=目标语言|原文 → 译文（""=无需翻译）
    private val pending = HashSet<String>()
    private var shownItems: List<String> = emptyList()
    private var detectedTheirLang: String? = null

    private var lastOriginal: String? = null
    private var lastTranslated: String? = null

    // ---------------- 生命周期 ----------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        tm = TranslatorManager()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlays()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        val relevant = pkg in WA_PACKAGES ||
                (overlaysShown && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)
        if (!relevant) return
        handler.removeCallbacks(scanRunnable)
        handler.postDelayed(scanRunnable, 200)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        setOverlaysVisible(false)
        if (::tm.isInitialized) tm.close()
        super.onDestroy()
    }

    // ---------------- 扫描聊天界面 ----------------

    private fun scan() {
        val root = rootInActiveWindow
        val pkg = root?.packageName?.toString()
        if (root == null || pkg == null || pkg !in WA_PACKAGES || !Prefs.enabled(this)) {
            setOverlaysVisible(false); return
        }
        // 只有在聊天页（有输入框）才显示
        if (findEntry(root, pkg) == null) { setOverlaysVisible(false); return }
        setOverlaysVisible(true)

        val screenW = resources.displayMetrics.widthPixels
        val rect = Rect()
        val incoming = ArrayList<Pair<Int, String>>()
        for (id in MESSAGE_IDS) {
            for (n in root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")) {
                val t = n.text?.toString()?.trim()
                if (t.isNullOrEmpty()) continue
                n.getBoundsInScreen(rect)
                // 对方消息气泡靠左，自己的靠右
                if (rect.left < screenW - rect.right) incoming.add(rect.top to t)
            }
        }
        val items = incoming.sortedBy { it.first }.map { it.second }.distinct().takeLast(MAX_ROWS)
        requestTranslations(items)
        if (items != shownItems) {
            shownItems = items
            renderPanel()
        }
    }

    private fun requestTranslations(items: List<String>) {
        val my = Prefs.myLang(this)
        val auto = Prefs.autoDetect(this)
        val their = Prefs.theirLang(this)
        val newest = items.lastOrNull()
        for (t in items) {
            val key = "$my|$t"
            if (results.get(key) != null || !pending.add(key)) continue
            val done = { r: String? ->
                pending.remove(key)
                results.put(key, r ?: ERR)
                if (t in shownItems) renderPanel()
            }
            if (auto) {
                tm.detectAndTranslate(t, my, their) { r, src ->
                    if (t == newest && r != null && r.isNotEmpty()) detectedTheirLang = src
                    done(r)
                }
            } else {
                tm.translate(t, their, my) { r -> done(if (r == t) "" else r) }
            }
        }
    }

    // ---------------- 发送方向：翻译输入框 ----------------

    private fun findEntry(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        for (id in ENTRY_IDS) {
            root.findAccessibilityNodeInfosByViewId("$pkg:id/$id").firstOrNull()?.let { return it }
        }
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
    }

    private fun currentEntry(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: return null
        if (pkg !in WA_PACKAGES) return null
        return findEntry(root, pkg)
    }

    private fun outgoingTarget(): String =
        if (Prefs.autoDetect(this)) detectedTheirLang ?: Prefs.theirLang(this) else Prefs.theirLang(this)

    private fun onBubbleTap() {
        val entry = currentEntry() ?: run { toast("请先打开一个 WhatsApp 聊天"); return }
        val showingHint = Build.VERSION.SDK_INT >= 26 && entry.isShowingHintText
        val text = if (showingHint) "" else entry.text?.toString().orEmpty()
        if (text.isBlank()) { toast("先在输入框里打字，再点“译”"); return }

        // 再点一次：还原原文
        if (text == lastTranslated && lastOriginal != null) {
            setEntryText(lastOriginal!!)
            lastTranslated = null
            toast("已还原原文")
            return
        }
        val src = Prefs.myLang(this)
        val tgt = outgoingTarget()
        if (src == tgt) { toast("我的语言和对方语言相同，请在 App 里设置"); return }

        bubble?.text = "…"
        tm.translate(text.trim(), src, tgt) { r ->
            bubble?.text = "译"
            if (r == null) {
                toast("翻译失败：请在 App 里下载${Langs.name(tgt)}模型")
                return@translate
            }
            lastOriginal = text
            lastTranslated = r
            setEntryText(r)
        }
    }

    private fun setEntryText(s: String) {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        }
        currentEntry()?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // ---------------- 悬浮窗 ----------------

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun createOverlays() {
        // 悬浮“译”按钮
        bubble = TextView(this).apply {
            text = "译"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E62F6FED"))
            }
            elevation = dp(4).toFloat()
        }
        bubbleParams = overlayParams(dp(48), dp(48)).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(6)
            y = (resources.displayMetrics.heightPixels * 0.55).toInt()
        }
        bubble!!.setOnTouchListener(BubbleTouch())

        // 顶部译文条
        panelHeader = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#B3FFFFFF"))
        }
        panelList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#D9202124"))
            }
            addView(panelHeader)
            addView(panelList)
            setOnClickListener { togglePanel() }
        }
        panelParams = overlayParams(
            resources.displayMetrics.widthPixels - dp(16),
            WindowManager.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(92)
        }
        renderPanel()
    }

    private fun setOverlaysVisible(v: Boolean) {
        if (v == overlaysShown) return
        overlaysShown = v
        try {
            if (v) {
                panel?.let { wm.addView(it, panelParams) }
                bubble?.let { wm.addView(it, bubbleParams) }
            } else {
                panel?.let { if (it.isAttachedToWindow) wm.removeView(it) }
                bubble?.let { if (it.isAttachedToWindow) wm.removeView(it) }
            }
        } catch (_: Exception) {
        }
    }

    private fun togglePanel() {
        panelCollapsed = !panelCollapsed
        renderPanel()
    }

    private fun renderPanel() {
        val list = panelList ?: return
        val header = panelHeader ?: return
        val my = Prefs.myLang(this)
        list.removeAllViews()
        if (panelCollapsed) {
            header.text = "▶ 译文已收起（点此展开）"
            return
        }
        val target = Langs.name(outgoingTarget())
        header.text = "▼ 译文 → ${Langs.name(my)}　·　回复将译成：$target"

        var count = 0
        for (orig in shownItems) {
            val r = results.get("$my|$orig")
            val tr = when {
                r == null -> "翻译中…"
                r == ERR -> "⚠ 翻译失败（请在 App 里下载模型）"
                r.isEmpty() -> continue     // 本来就是我的语言
                else -> r
            }
            list.addView(makeRow(orig, tr))
            count++
        }
        if (count == 0) {
            list.addView(TextView(this).apply {
                text = "（当前画面没有需要翻译的对方消息）"
                textSize = 13f
                setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding(0, dp(4), 0, 0)
            })
        }
    }

    private fun makeRow(orig: String, tr: String): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, 0)
            addView(TextView(context).apply {
                text = orig
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(Color.parseColor("#8CFFFFFF"))
            })
            addView(TextView(context).apply {
                text = tr
                textSize = 15f
                maxLines = 5
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(Color.WHITE)
            })
            setOnClickListener { togglePanel() }
            setOnLongClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("译文", tr))
                toast("已复制译文")
                true
            }
        }

    private inner class BubbleTouch : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false
        private var downAt = 0L

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = bubbleParams.x; startY = bubbleParams.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    downAt = SystemClock.uptimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        bubbleParams.x = startX - dx.toInt()   // Gravity.END：x 从右边算
                        bubbleParams.y = startY + dy.toInt()
                        try { wm.updateViewLayout(v, bubbleParams) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (SystemClock.uptimeMillis() - downAt > 500) togglePanel() else onBubbleTap()
                }
            }
            return true
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
