package com.watranslate

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener

/**
 * 内置 WhatsApp：在 App 里打开 WhatsApp 网页版（官方“关联设备”功能），
 * 把译文直接写进每一条聊天气泡里（双语对照），并提供“译”按钮翻译输入框。
 */
class WaWebActivity : Activity() {

    companion object {
        private const val WA_URL = "https://web.whatsapp.com/"
        private const val FILE_REQ = 7001
    }

    private lateinit var web: WebView
    private lateinit var tm: TranslatorManager
    private val handler = Handler(Looper.getMainLooper())
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var detectedTheirLang: String? = null
    private var lastOriginal: String? = null
    private var lastTranslated: String? = null
    private var mobileLayout = true

    private val injectTick = object : Runnable {
        override fun run() {
            inject()
            handler.postDelayed(this, 2500)
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tm = TranslatorManager(this)

        val root = FrameLayout(this)
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        // 右下角“译”按钮：单击翻译输入框；长按显示/隐藏译文
        val fab = roundButton("译", "#E62F6FED", 18f)
        fab.setOnClickListener { translateInput() }
        fab.setOnLongClickListener { toggleTranslations(); true }
        root.addView(fab, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.END or Gravity.BOTTOM).apply {
            rightMargin = dp(10); bottomMargin = dp(86)
        })

        // 左下角菜单：聊天列表 / 布局 / 刷新
        val menuBtn = roundButton("☰", "#CC444B53", 17f)
        menuBtn.setOnClickListener { showMenu(it) }
        root.addView(menuBtn, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.END or Gravity.BOTTOM).apply {
            rightMargin = dp(15); bottomMargin = dp(146)
        })
        banner = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#E6202124"))
            }
            visibility = View.GONE
        }
        root.addView(banner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(40); leftMargin = dp(16); rightMargin = dp(16)
        })
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            userAgentString = TranslatorManager.UA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(Bridge(), "WaTr")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { inject() }
            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                val host = u.host ?: ""
                if (host.endsWith("whatsapp.com") || host.endsWith("whatsapp.net")) return false
                // 聊天里的外部链接用系统浏览器打开
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), FILE_REQ); true
                } catch (_: Exception) { fileCb = null; false }
            }
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(WA_URL)
        handler.postDelayed(injectTick, 2500)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_REQ) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // 在聊天里按返回 → 回到聊天列表
        web.evaluateJavascript("window.__waBack ? __waBack() : false") { r ->
            if (r != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tm.close()
        web.destroy()
        super.onDestroy()
    }

    // ---------------- 注入到 WhatsApp 网页的脚本 ----------------

    private fun inject() {
        web.evaluateJavascript(INJECT_JS, null)
        web.evaluateJavascript("window.__waSetMobile && __waSetMobile(${mobileLayout})", null)
    }

    private val INJECT_JS = """
(function(){
  if (window.__waTrInit) { try{ __waScan(); __waLayout(); }catch(e){} return; }
  window.__waTrInit = 1;
  window.__waSeq = 0;
  window.__waMobile = true;
  window.__waShowList = false;

  var css = document.createElement('style');
  css.textContent =
    '.wa-tr{display:block;margin:4px 0 2px;padding:4px 7px;border-radius:6px;font-size:14px;line-height:1.4;white-space:pre-wrap;word-break:break-word;}' +
    '.wa-tr.in{background:rgba(255,200,60,.22);border-left:3px solid #e0a800;}' +
    '.wa-tr.out{background:rgba(70,130,240,.16);border-left:3px solid #3f7be0;}' +
    '.wa-tr.wait{opacity:.55;}' +
    'body.wa-tr-off .wa-tr{display:none!important;}';
  document.head.appendChild(css);

  // 手机布局：让网页宽度等于手机宽度
  var vp = document.createElement('meta');
  vp.name = 'viewport'; vp.id = 'wa-vp';
  vp.content = 'width=device-width,initial-scale=1,maximum-scale=3';
  document.head.appendChild(vp);

  function msgText(m){
    var s = m.querySelector('div.copyable-text[data-pre-plain-text] span.selectable-text') ||
            m.querySelector('span.selectable-text') ||
            m.querySelector('div.copyable-text span[dir]') ||
            m.querySelector('span[dir="auto"], span[dir="ltr"], span[dir="rtl"]');
    return s ? { el: s, text: (s.innerText || '').trim() } : null;
  }

  // 找到聊天窗口里的每条消息：新版用 data-id（true_ 开头=我发的，false_ 开头=对方），旧版用 message-in/out
  function findMessages(){
    var main = document.querySelector('#main') || document;
    var out = [];
    var seen = new Set();
    main.querySelectorAll('[data-id]').forEach(function(el){
      var id = el.getAttribute('data-id') || '';
      if (!/^(true|false)_/.test(id)) return;
      if (seen.has(el)) return;
      // 只取最外层的消息元素
      var p = el.parentElement, nested = false;
      while (p && p !== main) { if (p.hasAttribute && p.hasAttribute('data-id') && /^(true|false)_/.test(p.getAttribute('data-id')||'')) { nested = true; break; } p = p.parentElement; }
      if (nested) return;
      seen.add(el);
      out.push({ el: el, out: id.indexOf('true_') === 0 });
    });
    if (out.length === 0) {
      main.querySelectorAll('div.message-in, div.message-out').forEach(function(el){
        out.push({ el: el, out: el.classList.contains('message-out') });
      });
    }
    return out;
  }

  window.__waScan = function(){
    var list = findMessages();
    for (var i = 0; i < list.length; i++){
      var m = list[i].el;
      var t = msgText(m);
      if (!t || !t.text) continue;
      if (m.getAttribute('data-wa-tr') === t.text && m.querySelector('.wa-tr')) continue;   // 已翻译过且内容没变
      m.setAttribute('data-wa-tr', t.text);
      var old = m.querySelector('.wa-tr'); if (old) old.remove();
      var out = list[i].out;
      var id = 'watr' + (++window.__waSeq);
      var box = document.createElement('div');
      box.id = id; box.className = 'wa-tr wait ' + (out ? 'out' : 'in');
      box.textContent = '翻译中…';
      var holder = t.el.closest('div.copyable-text') || t.el.parentElement;
      holder.appendChild(box);
      try { WaTr.translate(id, t.text, out); } catch(e) { box.textContent = '⚠ ' + e; }
    }
  };

  // 输入框（新旧版本都兼容）
  window.__waInput = function(){
    return document.querySelector('footer div[contenteditable="true"]') ||
           document.querySelector('#main div[contenteditable="true"][role="textbox"]') ||
           document.querySelector('#main div[contenteditable="true"]') ||
           document.querySelector('div[contenteditable="true"][data-tab="10"]');
  };

  // 诊断信息（只统计页面结构，不读取任何聊天内容）
  window.__waDiag = function(){
    var main = document.querySelector('#main');
    var ids = main ? Array.prototype.map.call(main.querySelectorAll('[data-id]'), function(e){ return (e.getAttribute('data-id')||'').slice(0,6); }) : [];
    var firstMsg = main && main.querySelector('[data-id]');
    return JSON.stringify({
      side: !!document.querySelector('#side'),
      main: !!main,
      msgIn: document.querySelectorAll('.message-in').length,
      msgOut: document.querySelectorAll('.message-out').length,
      dataId: ids.length,
      dataIdPrefix: ids.slice(0,6),
      found: findMessages().length,
      selectable: document.querySelectorAll('span.selectable-text').length,
      copyable: document.querySelectorAll('.copyable-text').length,
      footer: !!document.querySelector('footer'),
      input: !!window.__waInput(),
      trBoxes: document.querySelectorAll('.wa-tr').length,
      bridge: typeof WaTr,
      msgTag: firstMsg ? (firstMsg.tagName + '.' + (firstMsg.className||'').toString().slice(0,60)) : '',
      ua: navigator.userAgent.slice(0,40)
    });
  };

  window.__trSet = function(id, txt){
    var b = document.getElementById(id);
    if (!b) return;
    if (!txt) { b.remove(); return; }
    b.textContent = txt; b.classList.remove('wait');
  };

  // ---- 手机布局：列表 / 聊天 二选一全屏显示 ----
  // 每次都先撤销上次改过的样式再重新计算，避免“越改越错”
  window.__waTouched = [];
  function setS(el, k, v){
    if (!el) return;
    if (window.__waTouched.indexOf(el) < 0) window.__waTouched.push(el);
    el.style[k] = v;
  }
  function resetAll(){
    window.__waTouched.forEach(function(el){
      ['display','flex','maxWidth','width','minWidth'].forEach(function(k){ el.style[k] = ''; });
    });
    window.__waTouched = [];
  }
  function columns(){
    var side = document.querySelector('#side');
    if (!side) return null;
    var main = document.querySelector('#main');
    if (main) {
      // 聊天列表和聊天窗口的“共同父层”，两边各自所在的那一栏
      var row = side;
      while (row && !row.contains(main)) row = row.parentElement;
      if (!row) return null;
      var col = side; while (col.parentElement !== row) col = col.parentElement;
      var mainCol = main; while (mainCol.parentElement !== row) mainCol = mainCol.parentElement;
      window.__waCol = col;
      return { col: col, row: row, mainCol: mainCol };
    }
    var cached = window.__waCol;
    if (cached && document.contains(cached) && cached.contains(side)) return { col: cached, row: cached.parentElement };
    var c = side;
    while (c.parentElement && c.parentElement.childElementCount < 2) c = c.parentElement;
    return { col: c, row: c.parentElement };
  }
  window.__waLayout = function(){
    resetAll();
    if (!window.__waMobile) return;
    var c = columns();
    if (!c || !c.row || c.row === document.body || c.row === document.documentElement) return;
    var main = document.querySelector('#main');
    var showChat = !!main && !window.__waShowList;
    var e = c.col;
    while (e && e !== document.body) { setS(e, 'minWidth', '0'); e = e.parentElement; }
    Array.prototype.forEach.call(c.row.children, function(ch){
      if (ch === c.col) {
        if (showChat) setS(ch, 'display', 'none');
        else { setS(ch, 'flex', '1 1 100%'); setS(ch, 'maxWidth', '100%'); setS(ch, 'width', '100%'); }
      } else if (showChat) {
        // 绝不隐藏聊天窗口
        if (ch === c.mainCol) { setS(ch, 'flex', '1 1 100%'); setS(ch, 'width', '100%'); }
        setS(ch, 'maxWidth', '100%'); setS(ch, 'minWidth', '0');
      } else {
        setS(ch, 'display', 'none');
      }
    });
    if (main) { var m = main; while (m && m !== c.row) { setS(m, 'minWidth', '0'); m = m.parentElement; } }
  };
  window.__waSetMobile = function(on){
    window.__waMobile = !!on;
    var v = document.getElementById('wa-vp');
    if (v) v.content = on ? 'width=device-width,initial-scale=1,maximum-scale=3' : 'width=1100';
    __waLayout();
  };
  window.__waBack = function(){
    if (window.__waMobile && document.querySelector('#main') && !window.__waShowList) {
      window.__waShowList = true; __waLayout(); return true;
    }
    return false;
  };
  window.__waList = function(){ window.__waShowList = true; __waLayout(); };
  document.addEventListener('click', function(e){
    var side = document.querySelector('#side');
    if (side && side.contains(e.target)) { window.__waShowList = false; setTimeout(__waLayout, 300); }
  }, true);

  var timer = null;
  new MutationObserver(function(){
    clearTimeout(timer);
    timer = setTimeout(function(){ try{ __waScan(); __waLayout(); }catch(e){} }, 250);
  }).observe(document.body, { childList: true, subtree: true });
  __waScan(); __waLayout();
})();
""".trimIndent()

    // ---------------- 网页 → App：翻译请求 ----------------

    private inner class Bridge {
        @JavascriptInterface
        fun translate(id: String, text: String, outgoing: Boolean) {
            handler.post { translateMessage(id, text, outgoing) }
        }
    }

    private fun translateMessage(id: String, text: String, outgoing: Boolean) {
        val my = Prefs.myLang(this)
        tm.detectLanguage(text, Prefs.theirLang(this)) { src ->
            val fail = "⚠ 翻译失败（请检查网络）"
            if (!outgoing) {
                // 对方的消息：译成我的语言
                if (src == my) setResult(id, "")
                else {
                    detectedTheirLang = src
                    tm.translate(text, src, my) { setResult(id, it ?: fail) }
                }
            } else {
                // 我发的消息：中文 → 译成对方语言；外语 → 译回中文
                if (src == my) {
                    val tgt = outgoingTarget()
                    if (tgt == my) setResult(id, "") else tm.translate(text, my, tgt) { setResult(id, it ?: fail) }
                } else tm.translate(text, src, my) { setResult(id, it ?: fail) }
            }
        }
    }

    private fun setResult(id: String, text: String) {
        web.evaluateJavascript(
            "window.__trSet && __trSet(${JSONObject.quote(id)}, ${JSONObject.quote(text)})", null
        )
    }

    private fun outgoingTarget(): String =
        if (Prefs.autoDetect(this)) detectedTheirLang ?: Prefs.theirLang(this) else Prefs.theirLang(this)

    // ---------------- 翻译输入框 ----------------

    private val GET_INPUT_JS =
        "(function(){var e=window.__waInput&&__waInput();return e?e.innerText:'__NOINPUT__';})()"

    private fun translateInput() {
        toast("正在读取输入框…")
        web.evaluateJavascript(GET_INPUT_JS) { raw ->
            val text = (try { JSONTokener(raw).nextValue() as? String } catch (_: Exception) { null })
                ?.trim().orEmpty()
            if (text == "__NOINPUT__") { toast("没找到输入框：请先打开一个聊天（如已打开，请点 ☰ → 诊断，把结果发给开发者）"); return@evaluateJavascript }
            if (text.isEmpty()) { toast("先打开一个聊天，在输入框里打字，再点“译”"); return@evaluateJavascript }
            if (text == lastTranslated && lastOriginal != null) {
                setInput(lastOriginal!!); lastTranslated = null; toast("已还原原文"); return@evaluateJavascript
            }
            val my = Prefs.myLang(this)
            val tgt = outgoingTarget()
            if (my == tgt) { toast("我的语言和对方语言相同，请在 App 里设置"); return@evaluateJavascript }
            toast("翻译中…")
            tm.translate(text, my, tgt) { r ->
                if (r == null) { toast("翻译失败，请检查网络"); return@translate }
                lastOriginal = text; lastTranslated = r
                setInput(r)
            }
        }
    }

    private fun setInput(s: String) {
        web.evaluateJavascript(
            "(function(t){var e=window.__waInput&&__waInput();" +
                    "if(!e)return;e.focus();document.execCommand('selectAll',false,null);" +
                    "document.execCommand('insertText',false,t);})(${JSONObject.quote(s)})", null
        )
    }

    // ---------------- 菜单 ----------------

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "聊天列表")
        pm.menu.add(0, 2, 1, "显示/隐藏译文")
        pm.menu.add(0, 3, 2, if (mobileLayout) "切换到电脑版布局" else "切换到手机版布局")
        pm.menu.add(0, 4, 3, "刷新")
        pm.menu.add(0, 5, 4, "设置")
        pm.menu.add(0, 6, 5, "诊断（翻译不出现时用）")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> web.evaluateJavascript("window.__waList && __waList()", null)
                2 -> toggleTranslations()
                3 -> { mobileLayout = !mobileLayout; inject() }
                4 -> web.reload()
                5 -> startActivity(Intent(this, MainActivity::class.java))
                6 -> showDiagnostics()
            }
            true
        }
        pm.show()
    }

    private fun showDiagnostics() {
        web.evaluateJavascript("window.__waDiag ? __waDiag() : 'NOT_INJECTED'") { raw ->
            val info = (try { JSONTokener(raw).nextValue()?.toString() } catch (_: Exception) { raw }) ?: raw
            val report = "engine=" + Prefs.engine(this) + " my=" + Prefs.myLang(this) +
                    " their=" + Prefs.theirLang(this) + "\n" + info
            android.app.AlertDialog.Builder(this)
                .setTitle("诊断信息（不含聊天内容）")
                .setMessage(report + "\n\n请点“复制”，然后粘贴发给开发者。")
                .setPositiveButton("复制") { _, _ ->
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("诊断", report))
                    toast("已复制")
                }
                .setNegativeButton("关闭", null)
                .show()
        }
    }

    private fun toggleTranslations() {
        web.evaluateJavascript("document.body.classList.toggle('wa-tr-off')") { r ->
            toast(if (r == "true") "已隐藏译文" else "已显示译文")
        }
    }

    private fun roundButton(label: String, color: String, size: Float) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(color))
        }
        elevation = dp(4).toFloat()
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private var banner: TextView? = null
    private val hideBanner = Runnable { banner?.visibility = View.GONE }

    /** 顶部提示条 + Toast（有些手机会屏蔽 Toast） */
    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        val b = banner ?: return
        b.text = s
        b.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, 3000)
    }
}
