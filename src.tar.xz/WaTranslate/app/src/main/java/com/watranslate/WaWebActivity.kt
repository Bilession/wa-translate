package com.watranslate

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener

/** 网页 → App 的桥（必须是公开的顶层类，WebView 才能调用） */
class WaBridge(private val act: WaWebActivity) {
    @JavascriptInterface
    fun translate(id: String, text: String, outgoing: Boolean) {
        act.runOnUiThread { act.translateMessage(id, text, outgoing) }
    }
}

/**
 * 内置 WhatsApp（网页版，官方“关联设备”功能）+ 谷歌翻译：
 *  - 每条消息气泡里直接显示译文（对方=黄色，我=蓝色）
 *  - 底部中文输入栏：边打中文边翻译，译文实时填进 WhatsApp 输入框，点“发送”发出译文
 */
class WaWebActivity : Activity() {

    companion object {
        private const val WA_URL = "https://web.whatsapp.com/"
        private const val FILE_REQ = 7001
        private const val LIVE_DELAY = 500L
    }

    private lateinit var web: WebView
    private lateinit var tm: TranslatorManager
    private val handler = Handler(Looper.getMainLooper())
    private var injectJs = ""
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var banner: TextView? = null
    private val hideBanner = Runnable { banner?.visibility = View.GONE }

    // 底部中文输入栏
    private lateinit var edit: EditText
    private lateinit var preview: TextView
    private lateinit var langBtn: TextView
    private lateinit var sendBtn: TextView

    private var detectedTheirLang: String? = null
    private var overrideTarget: String? = null     // 手动选的目标语言（本聊天有效）
    private var currentChat = ""
    private var chatOpen = false
    private var mobileLayout = true

    // 实时翻译状态
    private var liveSeq = 0                        // 防止旧结果覆盖新结果
    private var liveSource = ""                    // 已翻译的中文
    private var liveResult = ""                    // 对应译文
    private var liveTarget = ""                    // 对应目标语言
    private var sending = false

    // 状态提示用
    private var announcedOn = false
    private var zeroFoundTicks = 0
    private var warnedNoMsg = false
    private var warnedFail = false

    private val tick = object : Runnable {
        override fun run() {
            inject()
            checkStatus()
            handler.postDelayed(this, 2000)
        }
    }

    private val liveRunnable = Runnable { translateLive(sendAfter = false) }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tm = TranslatorManager(this)
        injectJs = assets.open("inject.js").bufferedReader(Charsets.UTF_8).use { it.readText() }

        // ---- 页面：上面是 WhatsApp，下面是中文输入栏 ----
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = FrameLayout(this)
        web = WebView(this)
        top.addView(web, FrameLayout.LayoutParams(-1, -1))

        banner = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rounded("#E6202124", 18)
            visibility = View.GONE
        }
        top.addView(banner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(36); leftMargin = dp(16); rightMargin = dp(16)
        })
        root.addView(top, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildInputBar(), LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = TranslatorManager.UA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(WaBridge(this), "WaTr")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { inject() }
            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                val host = u.host ?: ""
                if (host.endsWith("whatsapp.com") || host.endsWith("whatsapp.net")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), FILE_REQ); true
                } catch (_: Exception) { fileCb = null; false }
            }
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(WA_URL)
        handler.postDelayed(tick, 2000)
        updateBarState()
        selfTest()
    }

    // ---------------- 底部中文输入栏 ----------------

    private fun buildInputBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F3F5F8"))
            setPadding(dp(8), dp(6), dp(8), dp(8))
            elevation = dp(6).toFloat()
        }

        // 第一行：目标语言 + 译文预览
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        langBtn = TextView(this).apply {
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#2F6FED"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = rounded("#E3ECFF", 12)
            setOnClickListener { chooseTargetLang() }
        }
        preview = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#1F2328"))
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(4), 0)
            setTextIsSelectable(true)
        }
        row1.addView(langBtn, LinearLayout.LayoutParams(-2, -2))
        row1.addView(preview, LinearLayout.LayoutParams(0, -2, 1f))

        // 第二行：菜单 + 中文输入框 + 发送
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(0, dp(6), 0, 0)
        }
        val menuBtn = TextView(this).apply {
            text = "☰"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#444B53"))
            setOnClickListener { showMenu(it) }
        }
        edit = EditText(this).apply {
            textSize = 16f
            maxLines = 5
            minHeight = dp(44)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded("#FFFFFF", 22)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { onChineseChanged() }
            })
        }
        sendBtn = TextView(this).apply {
            text = "发送"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded("#25A35A", 22)
            setOnClickListener { onSendClicked() }
        }
        row2.addView(menuBtn, LinearLayout.LayoutParams(dp(40), dp(44)))
        row2.addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(sendBtn, LinearLayout.LayoutParams(dp(64), dp(44)).apply { leftMargin = dp(6) })

        bar.addView(row1, LinearLayout.LayoutParams(-1, -2))
        bar.addView(row2, LinearLayout.LayoutParams(-1, -2))
        return bar
    }

    private fun updateBarState() {
        val tgt = Langs.name(outgoingTarget()).substringBefore(' ')
        langBtn.text = "译成 $tgt ▾"
        edit.isEnabled = chatOpen
        sendBtn.isEnabled = chatOpen
        sendBtn.alpha = if (chatOpen) 1f else 0.4f
        edit.hint = if (chatOpen) "在这里打中文，自动翻译成$tgt" else "先打开一个聊天"
        if (edit.text.isNullOrBlank()) {
            preview.text = if (chatOpen) "译文会实时显示在这里，并自动填进 WhatsApp 输入框" else ""
            preview.setTextColor(Color.parseColor("#8A9099"))
        }
    }

    /** 中文变了：稍等一下再翻译，避免每个字都请求一次 */
    private fun onChineseChanged() {
        handler.removeCallbacks(liveRunnable)
        val text = edit.text.toString().trim()
        if (text.isEmpty()) {
            liveSeq++
            // 只清掉我们自己填进去的译文（切换聊天/发送后不会误删）
            if (liveResult.isNotEmpty()) setWaInput("")
            liveSource = ""; liveResult = ""
            updateBarState()
            return
        }
        preview.setTextColor(Color.parseColor("#8A9099"))
        preview.text = "翻译中…"
        handler.postDelayed(liveRunnable, LIVE_DELAY)
    }

    /** 实时翻译；sendAfter=true 时翻译完立刻发送 */
    private fun translateLive(sendAfter: Boolean) {
        val text = edit.text.toString().trim()
        if (text.isEmpty()) return
        val my = Prefs.myLang(this)
        val tgt = outgoingTarget()
        // 已经翻译过同样的内容：直接用
        if (text == liveSource && tgt == liveTarget && liveResult.isNotEmpty()) {
            if (sendAfter) doSend(liveResult)
            return
        }
        val seq = ++liveSeq
        if (my == tgt) { showLive(text, text, tgt, seq, sendAfter); return }
        tm.translate(text, my, tgt) { r ->
            if (seq != liveSeq) return@translate      // 已经有更新的输入了
            if (r == null) {
                preview.setTextColor(Color.parseColor("#C62828"))
                preview.text = "⚠ 翻译失败，请检查网络"
                sending = false
                return@translate
            }
            showLive(text, r, tgt, seq, sendAfter)
        }
    }

    private fun showLive(src: String, result: String, tgt: String, seq: Int, sendAfter: Boolean) {
        liveSource = src; liveResult = result; liveTarget = tgt
        preview.setTextColor(Color.parseColor("#1F2328"))
        preview.text = result
        setWaInput(result)
        if (sendAfter && seq == liveSeq) doSend(result)
    }

    private fun onSendClicked() {
        if (sending) return
        val text = edit.text.toString().trim()
        if (text.isEmpty()) { toast("先在下面输入中文"); return }
        sending = true
        handler.removeCallbacks(liveRunnable)
        translateLive(sendAfter = true)
    }

    /** 确保 WhatsApp 输入框里是译文，然后点 WhatsApp 的发送 */
    private fun doSend(result: String) {
        web.evaluateJavascript("window.__wa ? __wa.setInput(${JSONObject.quote(result)}) : 'noinput'") { r ->
            val state = jsString(r)
            if (state != "ok") {
                sending = false
                copyToClipboard(result)
                toast("没能写进 WhatsApp 输入框，译文已复制：请长按 WhatsApp 输入框粘贴后发送", 6000)
                return@evaluateJavascript
            }
            handler.postDelayed({
                web.evaluateJavascript("window.__wa ? __wa.send() : 'noinput'") { how ->
                    sending = false
                    if (jsString(how) == "noinput") { toast("没找到 WhatsApp 输入框"); return@evaluateJavascript }
                    // 发送成功：清空中文栏
                    liveSeq++
                    liveSource = ""; liveResult = ""
                    edit.setText("")
                    updateBarState()
                }
            }, 250)
        }
    }

    private fun setWaInput(text: String) {
        web.evaluateJavascript("window.__wa ? __wa.setInput(${JSONObject.quote(text)}) : 'noinput'") { r ->
            if (text.isNotEmpty() && jsString(r) == "fail") {
                preview.append("\n（未能自动填入 WhatsApp 输入框，点“发送”会复制译文）")
            }
        }
    }

    private fun chooseTargetLang() {
        val names = Langs.ALL.map { it.second }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("把我的话翻译成")
            .setItems(names) { _, i ->
                overrideTarget = Langs.ALL[i].first
                Prefs.setTheirLang(this, Langs.ALL[i].first)
                updateBarState()
                if (edit.text.isNotBlank()) translateLive(sendAfter = false)
            }
            .show()
    }

    // ---------------- 生命周期 ----------------

    /** 启动时测一下翻译服务通不通，结果显示在顶部 */
    private fun selfTest() {
        tm.translateAuto("Good morning", Prefs.myLang(this)) { r ->
            if (r == null) toast("⚠ 连不上谷歌/微软翻译，请检查网络（可能需要 VPN）", 6000)
            else toast("翻译服务正常（${r.engine}）：Good morning → ${r.text}", 3500)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::edit.isInitialized) updateBarState()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_REQ) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.__wa ? __wa.back() : false") { r ->
            if (r != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tm.close()
        web.destroy()
        super.onDestroy()
    }

    // ---------------- 注入脚本 / 状态 ----------------

    private fun inject() {
        web.evaluateJavascript(injectJs, null)
        web.evaluateJavascript("window.__wa && __wa.mobile !== $mobileLayout && __wa.setMobile($mobileLayout)", null)
    }

    /** 读取页面状态（只看数量和聊天是否切换，不读聊天内容） */
    private fun checkStatus() {
        web.evaluateJavascript("window.__wa ? __wa.stats() : ''") { raw ->
            val s = jsString(raw)
            if (s.isEmpty()) return@evaluateJavascript
            val o = try { JSONObject(s) } catch (_: Exception) { return@evaluateJavascript }
            val hasMain = o.optBoolean("main")
            val found = o.optInt("found")
            val chat = o.optString("chat")

            // 切换了聊天：重置语言和中文栏
            if (chat != currentChat) {
                currentChat = chat
                detectedTheirLang = null
                overrideTarget = null
                liveSeq++
                liveSource = ""; liveResult = ""
                if (edit.text.isNotEmpty()) edit.setText("")
            }
            val open = hasMain && o.optBoolean("input")
            if (open != chatOpen) { chatOpen = open; updateBarState() }

            if (hasMain && found > 0 && !announcedOn) {
                announcedOn = true
                toast("双语翻译已开启")
            }
            if (hasMain && found == 0) {
                zeroFoundTicks++
                if (zeroFoundTicks >= 3 && !warnedNoMsg) {
                    warnedNoMsg = true
                    toast("没识别到消息：请点 ☰ → 诊断，把结果发给开发者", 6000)
                }
            } else zeroFoundTicks = 0
            if (o.optInt("failed") > 0 && o.optInt("done") == 0 && !warnedFail) {
                warnedFail = true
                toast("⚠ 翻译失败：连不上谷歌/微软翻译，请检查网络", 6000)
            }
        }
    }

    // ---------------- 翻译消息气泡 ----------------

    fun translateMessage(id: String, text: String, outgoing: Boolean) {
        val my = Prefs.myLang(this)
        tm.translateAuto(text, my) { r ->
            if (r == null) {
                setResult(id, "⚠ 翻译失败（连不上谷歌/微软翻译）", true)
                return@translateAuto
            }
            val alreadyMine = r.src == my || r.text.trim().equals(text.trim(), ignoreCase = true)
            if (!alreadyMine) {
                // 外语消息 → 显示中文译文；对方用什么语言，我回复就译成什么语言
                if (!outgoing && r.src.isNotEmpty() && r.src != detectedTheirLang) {
                    detectedTheirLang = r.src
                    updateBarState()
                }
                setResult(id, r.text, false)
            } else if (outgoing) {
                val tgt = outgoingTarget()
                if (tgt == my) setResult(id, "", false)
                else tm.translate(text, my, tgt) { t ->
                    if (t == null) setResult(id, "⚠ 翻译失败", true) else setResult(id, t, false)
                }
            } else {
                setResult(id, "", false)
            }
        }
    }

    private fun setResult(id: String, text: String, failed: Boolean) {
        web.evaluateJavascript(
            "window.__trSet && __trSet(${JSONObject.quote(id)}, ${JSONObject.quote(text)}, $failed)", null
        )
    }

    private fun outgoingTarget(): String = overrideTarget
        ?: if (Prefs.autoDetect(this)) detectedTheirLang ?: Prefs.theirLang(this) else Prefs.theirLang(this)

    // ---------------- 菜单 ----------------

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "聊天列表")
        pm.menu.add(0, 2, 1, "显示/隐藏气泡译文")
        pm.menu.add(0, 3, 2, "翻译设置（语言 / 引擎）")
        pm.menu.add(0, 4, 3, if (mobileLayout) "切换到电脑版布局" else "切换到手机版布局")
        pm.menu.add(0, 5, 4, "刷新")
        pm.menu.add(0, 6, 5, "诊断（翻译出问题时用）")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> web.evaluateJavascript("window.__wa && __wa.list()", null)
                2 -> toggleTranslations()
                3 -> startActivity(Intent(this, MainActivity::class.java))
                4 -> { mobileLayout = !mobileLayout; inject() }
                5 -> web.reload()
                6 -> showDiagnostics()
            }
            true
        }
        pm.show()
    }

    private fun toggleTranslations() {
        web.evaluateJavascript("window.__wa ? __wa.setOff(!__wa.off) : null") { r ->
            toast(if (r == "true") "已隐藏气泡译文" else "已显示气泡译文")
        }
    }

    private fun showDiagnostics() {
        web.evaluateJavascript("window.__wa ? __wa.stats() : 'NOT_INJECTED'") { raw ->
            val info = jsString(raw).ifEmpty { raw }
            tm.translateAuto("Good morning", Prefs.myLang(this)) { r ->
                val net = if (r == null) "翻译服务：连不上" else "翻译服务：正常（${r.engine}）"
                val report = "v2.1 engine=${Prefs.engine(this)} my=${Prefs.myLang(this)} " +
                        "target=${outgoingTarget()}\n$net\n$info"
                AlertDialog.Builder(this)
                    .setTitle("诊断信息（不含聊天内容）")
                    .setMessage(report + "\n\n点“复制”，然后粘贴发给开发者。")
                    .setPositiveButton("复制") { _, _ -> copyToClipboard(report); toast("已复制") }
                    .setNegativeButton("关闭", null)
                    .show()
            }
        }
    }

    // ---------------- 小工具 ----------------

    private fun jsString(raw: String?): String =
        try { (JSONTokener(raw ?: "").nextValue() as? String) ?: "" } catch (_: Exception) { "" }

    private fun copyToClipboard(s: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("译文", s))
    }

    private fun rounded(color: String, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(Color.parseColor(color))
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun toast(s: String, ms: Long = 3000) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        val b = banner ?: return
        b.text = s
        b.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, ms)
    }
}
