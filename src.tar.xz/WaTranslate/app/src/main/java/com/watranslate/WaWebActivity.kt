package com.watranslate

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener

/** 网页 → App 的桥（必须是公开的顶层类，WebView 才能调用） */
class WaBridge(private val act: WaWebActivity) {
    @JavascriptInterface
    fun translate(id: String, text: String, outgoing: Boolean) {
        act.runOnUiThread { act.translateMessage(id, text, outgoing) }
    }
}

/**
 * 内置 WhatsApp（网页版，官方“关联设备”功能）+ 谷歌翻译：
 * 每条消息气泡里直接显示译文（对方=黄色，我=蓝色），右下“译”按钮翻译输入框。
 */
class WaWebActivity : Activity() {

    companion object {
        private const val WA_URL = "https://web.whatsapp.com/"
        private const val FILE_REQ = 7001
    }

    private lateinit var web: WebView
    private lateinit var tm: TranslatorManager
    private val handler = Handler(Looper.getMainLooper())
    private var injectJs = ""
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var banner: TextView? = null
    private val hideBanner = Runnable { banner?.visibility = View.GONE }

    private var detectedTheirLang: String? = null
    private var lastOriginal: String? = null
    private var lastTranslated: String? = null
    private var mobileLayout = true

    // 状态提示用
    private var announcedOn = false
    private var zeroFoundTicks = 0
    private var warnedNoMsg = false
    private var warnedFail = false

    private val tick = object : Runnable {
        override fun run() {
            inject()
            checkStatus()
            handler.postDelayed(this, 2500)
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tm = TranslatorManager(this)
        injectJs = assets.open("inject.js").bufferedReader(Charsets.UTF_8).use { it.readText() }

        val root = FrameLayout(this)
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        // 右下“译”按钮：单击翻译输入框；长按显示/隐藏译文
        val fab = roundButton("译", "#F02F6FED", 19f)
        fab.setOnClickListener { translateInput() }
        fab.setOnLongClickListener { toggleTranslations(); true }
        root.addView(fab, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END or Gravity.BOTTOM).apply {
            rightMargin = dp(10); bottomMargin = dp(88)
        })

        // 菜单按钮
        val menuBtn = roundButton("☰", "#D9444B53", 17f)
        menuBtn.setOnClickListener { showMenu(it) }
        root.addView(menuBtn, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.END or Gravity.BOTTOM).apply {
            rightMargin = dp(16); bottomMargin = dp(150)
        })

        // 顶部提示条（有些手机屏蔽 Toast，所以自己显示）
        banner = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#E6202124"))
            }
            visibility = View.GONE
        }
        root.addView(banner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(36); leftMargin = dp(16); rightMargin = dp(16)
        })
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = TranslatorManager.UA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(WaBridge(this), "WaTr")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { inject() }
            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                val host = u.host ?: ""
                if (host.endsWith("whatsapp.com") || host.endsWith("whatsapp.net")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), FILE_REQ); true
                } catch (_: Exception) { fileCb = null; false }
            }
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(WA_URL)
        handler.postDelayed(tick, 2500)
        selfTest()
    }

    /** 启动时测一下翻译服务通不通，结果显示在顶部 */
    private fun selfTest() {
        tm.translateAuto("Good morning", Prefs.myLang(this)) { r ->
            if (r == null) toast("⚠ 连不上谷歌/微软翻译，请检查网络（可能需要 VPN）", 6000)
            else toast("翻译服务正常（${r.engine}）：Good morning → ${r.text}", 3500)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_REQ) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.__wa ? __wa.back() : false") { r ->
            if (r != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tm.close()
        web.destroy()
        super.onDestroy()
    }

    // ---------------- 注入脚本 ----------------

    private fun inject() {
        web.evaluateJavascript(injectJs, null)
        web.evaluateJavascript("window.__wa && __wa.mobile !== $mobileLayout && __wa.setMobile($mobileLayout)", null)
    }

    /** 读取页面状态，给出提示（只看数量，不读聊天内容） */
    private fun checkStatus() {
        web.evaluateJavascript("window.__wa ? __wa.stats() : ''") { raw ->
            val s = try { JSONTokener(raw).nextValue() as? String } catch (_: Exception) { null }
            if (s.isNullOrEmpty()) return@evaluateJavascript
            val o = try { JSONObject(s) } catch (_: Exception) { return@evaluateJavascript }
            val hasMain = o.optBoolean("main")
            val found = o.optInt("found")
            if (hasMain && found > 0 && !announcedOn) {
                announcedOn = true
                toast("双语翻译已开启（识别到 $found 条消息）")
            }
            if (hasMain && found == 0) {
                zeroFoundTicks++
                if (zeroFoundTicks >= 3 && !warnedNoMsg) {
                    warnedNoMsg = true
                    toast("没识别到消息：请点 ☰ → 诊断，把结果发给开发者", 6000)
                }
            } else zeroFoundTicks = 0
            if (o.optInt("failed") > 0 && o.optInt("done") == 0 && !warnedFail) {
                warnedFail = true
                toast("⚠ 翻译失败：连不上谷歌/微软翻译，请检查网络", 6000)
            }
        }
    }

    // ---------------- 翻译消息 ----------------

    fun translateMessage(id: String, text: String, outgoing: Boolean) {
        val my = Prefs.myLang(this)
        tm.translateAuto(text, my) { r ->
            if (r == null) {
                setResult(id, "⚠ 翻译失败（连不上谷歌/微软翻译）", true)
                return@translateAuto
            }
            val alreadyMine = r.src == my || r.text.trim().equals(text.trim(), ignoreCase = true)
            if (!alreadyMine) {
                // 外语消息 → 显示中文译文
                if (!outgoing && r.src.isNotEmpty()) detectedTheirLang = r.src
                setResult(id, r.text, false)
            } else if (outgoing) {
                // 我用中文发的 → 显示对方语言译文
                val tgt = outgoingTarget()
                if (tgt == my) setResult(id, "", false)
                else tm.translate(text, my, tgt) { t ->
                    if (t == null) setResult(id, "⚠ 翻译失败", true) else setResult(id, t, false)
                }
            } else {
                // 对方也说中文 → 不需要翻译
                setResult(id, "", false)
            }
        }
    }

    private fun setResult(id: String, text: String, failed: Boolean) {
        web.evaluateJavascript(
            "window.__trSet && __trSet(${JSONObject.quote(id)}, ${JSONObject.quote(text)}, $failed)", null
        )
    }

    private fun outgoingTarget(): String =
        if (Prefs.autoDetect(this)) detectedTheirLang ?: Prefs.theirLang(this) else Prefs.theirLang(this)

    // ---------------- 翻译输入框 ----------------

    private fun translateInput() {
        toast("正在读取输入框…")
        web.evaluateJavascript("window.__wa ? __wa.getInput() : '__NOINPUT__'") { raw ->
            val text = (try { JSONTokener(raw).nextValue() as? String } catch (_: Exception) { null })
                ?.trim().orEmpty()
            if (text == "__NOINPUT__") { toast("没找到输入框：请先打开一个聊天"); return@evaluateJavascript }
            if (text.isEmpty()) { toast("先在输入框里打字，再点“译”"); return@evaluateJavascript }
            if (text == lastTranslated && lastOriginal != null) {
                setInput(lastOriginal!!); lastTranslated = null
                toast("已还原原文"); return@evaluateJavascript
            }
            val my = Prefs.myLang(this)
            val tgt = outgoingTarget()
            if (my == tgt) { toast("我的语言和对方语言相同，请在设置里修改"); return@evaluateJavascript }
            toast("翻译成${Langs.name(tgt)}…")
            tm.translate(text, my, tgt) { r ->
                if (r == null) { toast("翻译失败，请检查网络"); return@translate }
                lastOriginal = text; lastTranslated = r
                setInput(r)
                toast("已翻译成${Langs.name(tgt)}，确认后按发送")
            }
        }
    }

    private fun setInput(s: String) {
        web.evaluateJavascript("window.__wa && __wa.setInput(${JSONObject.quote(s)})", null)
    }

    // ---------------- 菜单 ----------------

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "聊天列表")
        pm.menu.add(0, 2, 1, "显示/隐藏译文")
        pm.menu.add(0, 3, 2, "翻译设置（语言 / 引擎）")
        pm.menu.add(0, 4, 3, if (mobileLayout) "切换到电脑版布局" else "切换到手机版布局")
        pm.menu.add(0, 5, 4, "刷新")
        pm.menu.add(0, 6, 5, "诊断（翻译不出现时用）")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> web.evaluateJavascript("window.__wa && __wa.list()", null)
                2 -> toggleTranslations()
                3 -> startActivity(Intent(this, MainActivity::class.java))
                4 -> { mobileLayout = !mobileLayout; inject() }
                5 -> web.reload()
                6 -> showDiagnostics()
            }
            true
        }
        pm.show()
    }

    private fun toggleTranslations() {
        web.evaluateJavascript("window.__wa ? __wa.setOff(!__wa.off) : null") { r ->
            toast(if (r == "true") "已隐藏译文" else "已显示译文")
        }
    }

    private fun showDiagnostics() {
        web.evaluateJavascript("window.__wa ? __wa.stats() : 'NOT_INJECTED'") { raw ->
            val info = (try { JSONTokener(raw).nextValue()?.toString() } catch (_: Exception) { raw }) ?: raw
            tm.translateAuto("Good morning", Prefs.myLang(this)) { r ->
                val net = if (r == null) "翻译服务：连不上" else "翻译服务：正常（${r.engine}）"
                val report = "v2.0 engine=${Prefs.engine(this)} my=${Prefs.myLang(this)} " +
                        "their=${Prefs.theirLang(this)}\n$net\n$info"
                AlertDialog.Builder(this)
                    .setTitle("诊断信息（不含聊天内容）")
                    .setMessage(report + "\n\n点“复制”，然后粘贴发给开发者。")
                    .setPositiveButton("复制") { _, _ ->
                        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("诊断", report))
                        toast("已复制")
                    }
                    .setNegativeButton("关闭", null)
                    .show()
            }
        }
    }

    // ---------------- 小工具 ----------------

    private fun roundButton(label: String, color: String, size: Float) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(color))
        }
        elevation = dp(4).toFloat()
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun toast(s: String, ms: Long = 3000) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        val b = banner ?: return
        b.text = s
        b.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, ms)
    }
}
