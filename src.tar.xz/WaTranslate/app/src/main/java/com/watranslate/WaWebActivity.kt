package com.watranslate

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener

/** 网页 → App 的桥（必须是公开的顶层类，WebView 才能调用） */
class WaBridge(private val act: WaWebActivity) {
    @JavascriptInterface
    fun translate(id: String, text: String, outgoing: Boolean) {
        act.runOnUiThread { act.translateMessage(id, text, outgoing) }
    }
}

/**
 * 内置 WhatsApp（网页版，官方“关联设备”功能）+ 谷歌翻译：
 *  - 每条消息气泡里直接显示译文（对方=黄色，我=蓝色）
 *  - 底部中文输入栏：边打中文边翻译，译文显示在“译文确认框”里（可修改），
 *    点“确认译文”后才填进 WhatsApp 输入框并发送
 */
class WaWebActivity : Activity() {

    companion object {
        private const val WA_URL = "https://web.whatsapp.com/"
        private const val FILE_REQ = 7001
        private const val LIVE_DELAY = 500L
    }

    private lateinit var web: WebView
    private lateinit var tm: TranslatorManager
    private val handler = Handler(Looper.getMainLooper())
    private var injectJs = ""
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var banner: TextView? = null
    private val hideBanner = Runnable { banner?.visibility = View.GONE }

    // 底部中文输入栏
    private lateinit var edit: EditText            // 中文输入
    private lateinit var trEdit: EditText          // 译文确认框（可修改）
    private lateinit var status: TextView          // 译文状态提示
    private lateinit var langBtn: TextView
    private lateinit var sendBtn: TextView

    private var detectedTheirLang: String? = null
    private var overrideTarget: String? = null     // 手动选的目标语言（本聊天有效）
    private var currentChat = ""
    private var chatOpen = false
    private var mobileLayout = true

    // 实时翻译状态
    private var liveSeq = 0                        // 防止旧结果覆盖新结果
    private var liveSource = ""                    // 已翻译的中文
    private var liveResult = ""                    // 对应译文
    private var liveTarget = ""                    // 对应目标语言
    private var sending = false
    private var settingTr = false                  // 程序正在写译文框（不算用户修改）
    private var trEditedByUser = false

    // 状态提示用
    private var announcedOn = false
    private var zeroFoundTicks = 0
    private var warnedNoMsg = false
    private var warnedFail = false

    private val tick = object : Runnable {
        override fun run() {
            inject()
            checkStatus()
            handler.postDelayed(this, 2000)
        }
    }

    private val liveRunnable = Runnable { translateLive(sendAfter = false) }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tm = TranslatorManager(this)
        injectJs = assets.open("inject.js").bufferedReader(Charsets.UTF_8).use { it.readText() }

        // ---- 页面：上面是 WhatsApp，下面是中文输入栏 ----
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = FrameLayout(this)
        web = WebView(this)
        top.addView(web, FrameLayout.LayoutParams(-1, -1))

        banner = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rounded("#E6202124", 18)
            visibility = View.GONE
        }
        top.addView(banner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(36); leftMargin = dp(16); rightMargin = dp(16)
        })
        root.addView(top, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildInputBar(), LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = TranslatorManager.UA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(WaBridge(this), "WaTr")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { inject() }
            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                val host = u.host ?: ""
                if (host.endsWith("whatsapp.com") || host.endsWith("whatsapp.net")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), FILE_REQ); true
                } catch (_: Exception) { fileCb = null; false }
            }
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(WA_URL)
        handler.postDelayed(tick, 2000)
        updateBarState()
        selfTest()
    }

    // ---------------- 底部：中文输入 + 译文确认框 ----------------

    private fun buildInputBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F3F5F8"))
            setPadding(dp(8), dp(6), dp(8), dp(8))
            elevation = dp(6).toFloat()
        }

        // 第一行：目标语言 + 状态
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        langBtn = TextView(this).apply {
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#2F6FED"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = rounded("#E3ECFF", 12)
            setOnClickListener { chooseTargetLang() }
        }
        status = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#8A9099"))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(4), 0)
        }
        row1.addView(langBtn, LinearLayout.LayoutParams(-2, -2))
        row1.addView(status, LinearLayout.LayoutParams(0, -2, 1f))

        // 第二行：译文确认框（实时更新，也可以直接改）
        trEdit = EditText(this).apply {
            textSize = 15f
            maxLines = 4
            minHeight = dp(40)
            setTextColor(Color.parseColor("#1F2328"))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#E8F0FF"))
                setStroke(dp(1), Color.parseColor("#9DB8F0"))
            }
            hint = "译文会实时显示在这里，可以直接修改"
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (!settingTr) { trEditedByUser = true; refreshButton() }
                }
            })
        }

        // 第三行：菜单 + 中文输入框 + 确认译文
        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(0, dp(6), 0, 0)
        }
        val menuBtn = TextView(this).apply {
            text = "☰"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#444B53"))
            setOnClickListener { showMenu(it) }
        }
        edit = EditText(this).apply {
            textSize = 16f
            maxLines = 5
            minHeight = dp(44)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded("#FFFFFF", 22)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { onChineseChanged() }
            })
        }
        sendBtn = TextView(this).apply {
            text = "确认译文"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded("#25A35A", 22)
            setOnClickListener { onConfirmClicked() }
        }
        row3.addView(menuBtn, LinearLayout.LayoutParams(dp(40), dp(44)))
        row3.addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
        row3.addView(sendBtn, LinearLayout.LayoutParams(dp(84), dp(44)).apply { leftMargin = dp(6) })

        bar.addView(row1, LinearLayout.LayoutParams(-1, -2))
        bar.addView(trEdit, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        bar.addView(row3, LinearLayout.LayoutParams(-1, -2))
        return bar
    }

    private fun updateBarState() {
        val tgt = Langs.name(outgoingTarget()).substringBefore(' ')
        langBtn.text = "译成 $tgt ▾"
        edit.isEnabled = chatOpen
        trEdit.isEnabled = chatOpen
        edit.hint = if (chatOpen) "在这里打中文" else "先打开一个聊天"
        if (edit.text.isNullOrBlank() && trEdit.text.isNullOrBlank()) {
            setStatus(if (chatOpen) "打中文 → 下面实时出译文 → 检查/修改 → 点“确认译文”发送" else "", false)
        }
        refreshButton()
    }

    private fun refreshButton() {
        val ok = chatOpen && !sending && (trEdit.text.isNotBlank() || edit.text.isNotBlank())
        sendBtn.isEnabled = ok
        sendBtn.alpha = if (ok) 1f else 0.4f
        sendBtn.text = if (sending) "发送中…" else "确认译文"
    }

    private fun setStatus(s: String, error: Boolean) {
        status.text = s
        status.setTextColor(Color.parseColor(if (error) "#C62828" else "#8A9099"))
    }

    /** 程序写译文框（不触发“用户修改”标记） */
    private fun setTranslation(t: String) {
        settingTr = true
        trEdit.setText(t)
        trEdit.setSelection(trEdit.text.length)
        settingTr = false
        trEditedByUser = false
        refreshButton()
    }

    /** 中文变了：稍等一下再翻译，避免每个字都请求一次。不会碰 WhatsApp 输入框。 */
    private fun onChineseChanged() {
        handler.removeCallbacks(liveRunnable)
        val text = edit.text.toString().trim()
        if (text.isEmpty()) {
            liveSeq++
            liveSource = ""; liveResult = ""
            setTranslation("")
            updateBarState()
            return
        }
        trEditedByUser = false      // 中文改了，以新译文为准
        setStatus("翻译中…", false)
        refreshButton()
        handler.postDelayed(liveRunnable, LIVE_DELAY)
    }

    /** 实时翻译，结果只放进译文确认框；sendAfter=true 时翻译完接着填入并发送 */
    private fun translateLive(sendAfter: Boolean) {
        val text = edit.text.toString().trim()
        if (text.isEmpty()) { sending = false; refreshButton(); return }
        val my = Prefs.myLang(this)
        val tgt = outgoingTarget()
        if (text == liveSource && tgt == liveTarget && liveResult.isNotEmpty()) {
            if (sendAfter) fillAndSend(trEdit.text.toString().trim())
            return
        }
        val seq = ++liveSeq
        if (my == tgt) { showLive(text, text, tgt, seq, sendAfter); return }
        tm.translate(text, my, tgt) { r ->
            if (seq != liveSeq) return@translate      // 已经有更新的输入了
            if (r == null) {
                setStatus("⚠ 翻译失败，请检查网络（也可以直接在上面框里手写译文）", true)
                sending = false
                refreshButton()
                return@translate
            }
            showLive(text, r, tgt, seq, sendAfter)
        }
    }

    private fun showLive(src: String, result: String, tgt: String, seq: Int, sendAfter: Boolean) {
        liveSource = src; liveResult = result; liveTarget = tgt
        setTranslation(result)
        setStatus("译文已更新（${Langs.name(tgt).substringBefore(' ')}），可修改；确认无误点“确认译文”", false)
        if (sendAfter && seq == liveSeq) fillAndSend(result)
    }

    /** 点“确认译文” */
    private fun onConfirmClicked() {
        if (sending) return
        val zh = edit.text.toString().trim()
        val tr = trEdit.text.toString().trim()
        if (zh.isEmpty() && tr.isEmpty()) { toast("先在下面输入中文"); return }
        sending = true
        refreshButton()
        handler.removeCallbacks(liveRunnable)
        // 用户改过译文，或译文已对应当前中文：直接用框里的译文
        val upToDate = zh.isEmpty() || trEditedByUser ||
                (zh == liveSource && outgoingTarget() == liveTarget && tr.isNotEmpty())
        if (upToDate && tr.isNotEmpty()) fillAndSend(tr)
        else translateLive(sendAfter = true)   // 中文刚改过还没翻译完：先翻译再发
    }

    private fun norm(s: String) = s.replace(' ', ' ').replace(Regex("\\s+"), " ").trim()

    /**
     * 把译文一次性填进 WhatsApp 输入框 → 等页面更新后核对 → 一致才点发送。
     * 绝不在核对前补写，避免出现“译文重复两遍”。
     */
    private fun fillAndSend(text: String) {
        if (text.isEmpty()) { sending = false; refreshButton(); return }
        web.evaluateJavascript("window.__wa ? __wa.setInput(${JSONObject.quote(text)}) : 'noinput'") { r ->
            if (jsString(r) == "noinput") { fillFailed(text, "没找到 WhatsApp 输入框"); return@evaluateJavascript }
            handler.postDelayed({ verifyThenSend(text, triedPaste = false) }, 350)
        }
    }

    private fun verifyThenSend(text: String, triedPaste: Boolean) {
        web.evaluateJavascript("window.__wa ? __wa.getInput() : '__NOINPUT__'") { raw ->
            val now = norm(jsString(raw))
            when {
                now == norm(text) -> clickSend()
                now.isEmpty() && !triedPaste -> {
                    // 第一种方法没写进去（输入框还是空的），才换粘贴方式写一次
                    web.evaluateJavascript("window.__wa ? __wa.pasteInput(${JSONObject.quote(text)}) : 'noinput'") {
                        handler.postDelayed({ verifyThenSend(text, triedPaste = true) }, 350)
                    }
                }
                else -> {
                    // 内容对不上：清空 WhatsApp 输入框，不发送
                    web.evaluateJavascript("window.__wa && __wa.setInput('')", null)
                    fillFailed(text, "没能正确填入 WhatsApp 输入框")
                }
            }
        }
    }

    private fun fillFailed(text: String, why: String) {
        sending = false
        refreshButton()
        copyToClipboard(text)
        setStatus("⚠ $why，译文已复制：长按 WhatsApp 输入框粘贴后发送", true)
        toast("$why，译文已复制，请长按 WhatsApp 输入框粘贴", 6000)
    }

    private fun clickSend() {
        web.evaluateJavascript("window.__wa ? __wa.send() : 'noinput'") { how ->
            if (jsString(how) == "noinput") {
                sending = false; refreshButton()
                toast("没找到 WhatsApp 的发送按钮，译文已在输入框里，请手动点发送", 5000)
                return@evaluateJavascript
            }
            // 已发送：清空中文和译文
            sending = false
            liveSeq++
            liveSource = ""; liveResult = ""
            handler.removeCallbacks(liveRunnable)
            edit.setText("")
            setTranslation("")
            setStatus("已发送 ✓", false)
            refreshButton()
        }
    }

    private fun chooseTargetLang() {
        val names = Langs.ALL.map { it.second }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("把我的话翻译成")
            .setItems(names) { _, i ->
                overrideTarget = Langs.ALL[i].first
                Prefs.setTheirLang(this, Langs.ALL[i].first)
                updateBarState()
                if (edit.text.isNotBlank()) { liveSource = ""; translateLive(sendAfter = false) }
            }
            .show()
    }

    // ---------------- 生命周期 ----------------

    /** 启动时测一下翻译服务通不通，结果显示在顶部 */
    private fun selfTest() {
        tm.translateAuto("Good morning", Prefs.myLang(this)) { r ->
            if (r == null) toast("⚠ 连不上谷歌/微软翻译，请检查网络（可能需要 VPN）", 6000)
            else toast("翻译服务正常（${r.engine}）：Good morning → ${r.text}", 3500)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::edit.isInitialized) updateBarState()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_REQ) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.__wa ? __wa.back() : false") { r ->
            if (r != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tm.close()
        web.destroy()
        super.onDestroy()
    }

    // ---------------- 注入脚本 / 状态 ----------------

    private fun inject() {
        web.evaluateJavascript(injectJs, null)
        web.evaluateJavascript("window.__wa && __wa.mobile !== $mobileLayout && __wa.setMobile($mobileLayout)", null)
    }

    /** 读取页面状态（只看数量和聊天是否切换，不读聊天内容） */
    private fun checkStatus() {
        web.evaluateJavascript("window.__wa ? __wa.stats() : ''") { raw ->
            val s = jsString(raw)
            if (s.isEmpty()) return@evaluateJavascript
            val o = try { JSONObject(s) } catch (_: Exception) { return@evaluateJavascript }
            val hasMain = o.optBoolean("main")
            val found = o.optInt("found")
            val chat = o.optString("chat")

            // 切换了聊天：重置语言和中文栏
            if (chat != currentChat) {
                currentChat = chat
                detectedTheirLang = null
                overrideTarget = null
                liveSeq++
                liveSource = ""; liveResult = ""
                if (edit.text.isNotEmpty()) edit.setText("")
                if (trEdit.text.isNotEmpty()) setTranslation("")
            }
            val open = hasMain && o.optBoolean("input")
            if (open != chatOpen) { chatOpen = open; updateBarState() }

            if (hasMain && found > 0 && !announcedOn) {
                announcedOn = true
                toast("双语翻译已开启")
            }
            if (hasMain && found == 0) {
                zeroFoundTicks++
                if (zeroFoundTicks >= 3 && !warnedNoMsg) {
                    warnedNoMsg = true
                    toast("没识别到消息：请点 ☰ → 诊断，把结果发给开发者", 6000)
                }
            } else zeroFoundTicks = 0
            if (o.optInt("failed") > 0 && o.optInt("done") == 0 && !warnedFail) {
                warnedFail = true
                toast("⚠ 翻译失败：连不上谷歌/微软翻译，请检查网络", 6000)
            }
        }
    }

    // ---------------- 翻译消息气泡 ----------------

    fun translateMessage(id: String, text: String, outgoing: Boolean) {
        val my = Prefs.myLang(this)
        tm.translateAuto(text, my) { r ->
            if (r == null) {
                setResult(id, "⚠ 翻译失败（连不上谷歌/微软翻译）", true)
                return@translateAuto
            }
            val alreadyMine = r.src == my || r.text.trim().equals(text.trim(), ignoreCase = true)
            if (!alreadyMine) {
                // 外语消息 → 显示中文译文；对方用什么语言，我回复就译成什么语言
                if (!outgoing && r.src.isNotEmpty() && r.src != detectedTheirLang) {
                    detectedTheirLang = r.src
                    updateBarState()
                }
                setResult(id, r.text, false)
            } else if (outgoing) {
                val tgt = outgoingTarget()
                if (tgt == my) setResult(id, "", false)
                else tm.translate(text, my, tgt) { t ->
                    if (t == null) setResult(id, "⚠ 翻译失败", true) else setResult(id, t, false)
                }
            } else {
                setResult(id, "", false)
            }
        }
    }

    private fun setResult(id: String, text: String, failed: Boolean) {
        web.evaluateJavascript(
            "window.__trSet && __trSet(${JSONObject.quote(id)}, ${JSONObject.quote(text)}, $failed)", null
        )
    }

    private fun outgoingTarget(): String = overrideTarget
        ?: if (Prefs.autoDetect(this)) detectedTheirLang ?: Prefs.theirLang(this) else Prefs.theirLang(this)

    // ---------------- 菜单 ----------------

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "聊天列表")
        pm.menu.add(0, 2, 1, "显示/隐藏气泡译文")
        pm.menu.add(0, 3, 2, "翻译设置（语言 / 引擎）")
        pm.menu.add(0, 4, 3, if (mobileLayout) "切换到电脑版布局" else "切换到手机版布局")
        pm.menu.add(0, 5, 4, "刷新")
        pm.menu.add(0, 6, 5, "诊断（翻译出问题时用）")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> web.evaluateJavascript("window.__wa && __wa.list()", null)
                2 -> toggleTranslations()
                3 -> startActivity(Intent(this, MainActivity::class.java))
                4 -> { mobileLayout = !mobileLayout; inject() }
                5 -> web.reload()
                6 -> showDiagnostics()
            }
            true
        }
        pm.show()
    }

    private fun toggleTranslations() {
        web.evaluateJavascript("window.__wa ? __wa.setOff(!__wa.off) : null") { r ->
            toast(if (r == "true") "已隐藏气泡译文" else "已显示气泡译文")
        }
    }

    private fun showDiagnostics() {
        web.evaluateJavascript("window.__wa ? __wa.stats() : 'NOT_INJECTED'") { raw ->
            val info = jsString(raw).ifEmpty { raw }
            tm.translateAuto("Good morning", Prefs.myLang(this)) { r ->
                val net = if (r == null) "翻译服务：连不上" else "翻译服务：正常（${r.engine}）"
                val report = "v2.2 engine=${Prefs.engine(this)} my=${Prefs.myLang(this)} " +
                        "target=${outgoingTarget()}\n$net\n$info"
                AlertDialog.Builder(this)
                    .setTitle("诊断信息（不含聊天内容）")
                    .setMessage(report + "\n\n点“复制”，然后粘贴发给开发者。")
                    .setPositiveButton("复制") { _, _ -> copyToClipboard(report); toast("已复制") }
                    .setNegativeButton("关闭", null)
                    .show()
            }
        }
    }

    // ---------------- 小工具 ----------------

    private fun jsString(raw: String?): String =
        try { (JSONTokener(raw ?: "").nextValue() as? String) ?: "" } catch (_: Exception) { "" }

    private fun copyToClipboard(s: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("译文", s))
    }

    private fun rounded(color: String, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(Color.parseColor(color))
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun toast(s: String, ms: Long = 3000) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        val b = banner ?: return
        b.text = s
        b.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, ms)
    }
}
