plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.watranslate"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.watranslate"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "2.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// 不依赖任何第三方库：翻译走谷歌/微软免费网页接口，不消耗 token
dependencies {}
